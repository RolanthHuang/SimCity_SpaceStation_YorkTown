export const SIZE=536; // Number of cells around the complete arm.
export const HEIGHT=56;
export const CELL_COUNT=SIZE*HEIGHT;
export const VERSION=3;
export const TYPES={
  road:{name:'道路',cost:12,upkeep:.12,color:0x40546b,group:'transport',capacity:60},
  avenue:{name:'幹道',cost:32,upkeep:.3,color:0x5e6b83,group:'transport',capacity:180},
  rail:{name:'磁浮軌道',cost:24,upkeep:.2,color:0x9ab5c7,group:'transport',capacity:500},
  station:{name:'磁浮車站',cost:650,upkeep:14,color:0xa2c6da,group:'transport',jobs:8},
  bus:{name:'接駁車總站',cost:550,upkeep:16,color:0x8ecfea,group:'transport',jobs:8},
  dock:{name:'貨運船塢',cost:2200,upkeep:25,color:0xeac28b,group:'transport',jobs:32},
  airport:{name:'星際客運港',cost:4500,upkeep:55,color:0xd3dee8,group:'transport',jobs:50,unlock:800},
  r:{name:'低密度住宅',cost:20,color:0x73cfa4,group:'zone',zone:'R',base:20},
  R:{name:'高密度住宅',cost:55,color:0x47bda0,group:'zone',zone:'R',base:55},
  c:{name:'低密度商業',cost:25,color:0x70aee3,group:'zone',zone:'C',base:12},
  C:{name:'高密度商業',cost:60,color:0x4685c9,group:'zone',zone:'C',base:30},
  i:{name:'輕工業',cost:25,color:0xe4bd69,group:'zone',zone:'I',base:20},
  I:{name:'重工業',cost:65,color:0xca9253,group:'zone',zone:'I',base:45},
  power:{name:'融合電廠',cost:2400,upkeep:40,color:0xf4c979,group:'utility',supply:6000,jobs:16},
  solar:{name:'太陽能陣列',cost:1100,upkeep:10,color:0x748ee8,group:'utility',supply:1800,jobs:3},
  water:{name:'水循環廠',cost:1500,upkeep:25,color:0x71cfea,group:'utility',supply:6000,jobs:10},
  life:{name:'生命維持中心',cost:1900,upkeep:26,color:0x8de4b7,group:'utility',jobs:12,oxygen:2400},
  radiator:{name:'散熱控制站',cost:1600,upkeep:20,color:0x86b6ee,group:'utility',jobs:8,cooling:7000},
  wire:{name:'電力管線',cost:4,color:0xffd27c,group:'network'},
  pipe:{name:'供水管線',cost:4,color:0x70cfff,group:'network'},
  fire:{name:'消防局',cost:1100,upkeep:28,color:0xe87f75,group:'service',radius:9,jobs:12},
  police:{name:'警察局',cost:1100,upkeep:28,color:0x8d9ce9,group:'service',radius:9,jobs:12},
  school:{name:'學校',cost:1400,upkeep:32,color:0xe5d5a7,group:'service',radius:11,jobs:16,capacity:600},
  hospital:{name:'醫院',cost:1800,upkeep:42,color:0xe3edf2,group:'service',radius:11,jobs:24,capacity:900},
  park:{name:'生態公園',cost:180,upkeep:3,color:0x51b88b,group:'service',radius:5},
  stadium:{name:'公共會館',cost:3000,upkeep:28,color:0xc4a9ef,group:'service',radius:16,unlock:400,jobs:20},
  arcology:{name:'垂直居住塔',cost:20000,upkeep:90,color:0x8ff7df,group:'special',base:500,zone:'R',unlock:2000},
  rubble:{name:'受損地塊',cost:0,color:0x655c64,group:'damage'},
};
export const GROUPS=[['inspect','檢視'],['zone','分區'],['transport','交通'],['utility','水電'],['service','服務'],['special','地標'],['bulldoze','拆除']];
export const FUNDING={utilities:'水電維護',transport:'交通維護',fire:'消防',police:'治安',school:'教育',hospital:'醫療',parks:'公園文化'};
export const POLICIES={green:{name:'清潔工業規範',description:'工業污染降低 40%；每名工業職位每月支出 0.08。'},transit:{name:'大眾運輸補助',description:'道路承載量增加 35%；每位居民每月支出 0.05。'},campaign:{name:'招商與移居計畫',description:'住宅與商業需求增加 12；每月支出 35。'}};
export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export const idx=(x,y)=>y*SIZE+x;
export const xy=i=>[i%SIZE,Math.floor(i/SIZE)];
export const wrapX=x=>((x%SIZE)+SIZE)%SIZE;
export const deltaX=(a,b)=>{let d=wrapX(b-a);return d>SIZE/2?d-SIZE:d;};
export const neighbors=i=>{const [x,y]=xy(i);return [idx(wrapX(x-1),y),idx(wrapX(x+1),y),y>0?i-SIZE:-1,y<HEIGHT-1?i+SIZE:-1].filter(n=>n>=0);};
export const DECK={minX:0,maxX:SIZE-1,minY:8,maxY:43,radius:SIZE/(Math.PI*2)};
export function terrain(i){if(!Number.isInteger(i)||i<0||i>=CELL_COUNT)return false;const [,y]=xy(i);return y>=DECK.minY&&y<=DECK.maxY;}
export const SECTORS=['曙光','星港','晨星','天頂','遠航','星雲','暮光','歸航'];
export const sectorX=n=>wrapX(20+Math.round(n*SIZE/8));
export function district(i){const [x]=xy(i);return '曙光環臂 · '+SECTORS[Math.floor(wrapX(x-20+SIZE/16)/(SIZE/8))]+'區';}
export const upgradeFactor=c=>1+(c.upgrade||0)*.25;
export const isEnabled=c=>c.enabled!==false;
export const INTERIORS={power:'融合控制室',water:'循環水監控室',life:'生態維持大廳',radiator:'散熱調度室',hospital:'醫療接待大廳',station:'磁浮候車大廳',dock:'貨運調度中心',airport:'星港候船大廳',stadium:'公共會館',arcology:'垂直城市大廳'};
export const isRoad=t=>t==='road'||t==='avenue';
export const isTransport=t=>isRoad(t)||t==='rail';
export const zoneOf=t=>TYPES[t]?.zone;
export const residential=t=>zoneOf(t)==='R';
