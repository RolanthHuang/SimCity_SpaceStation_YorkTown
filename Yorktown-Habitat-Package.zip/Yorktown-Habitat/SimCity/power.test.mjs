import test from 'node:test';
import assert from 'node:assert/strict';
import {createCity,step,build,analyze,forecast,serialize,deserialize,renewPlant} from './engine.mjs';
import {idx,TYPES} from './catalog.mjs';
const plant=idx(12,14);
const fresh=()=>{const s=createCity();s.disasters=false;return s;};
test('Automatic replacement costs the build price, resets age, preserves supply and records capital spending',()=>{
 const s=fresh();s.cells[plant].age=599;const before=s.cash,pop=analyze(s).stats.population;step(s);
 assert.equal(s.cells[plant].type,'power');assert.equal(s.cells[plant].age,0);assert.equal(analyze(s).power.supply,6000);assert.ok(analyze(s).stats.population>=pop);
 assert.equal(s.lastRenewal.cost,TYPES.power.cost);assert.ok(Math.abs(s.cash-before-s.history.at(-1).net)<.011);assert.ok(Math.abs(s.history.at(-1).net-(forecast(s).net-TYPES.power.cost))<.011);
});
test('Disabled replacement becomes visible rubble with no generation or jobs',()=>{
 const s=fresh();s.powerRenewal=false;s.cells[plant].age=599;step(s);const c=s.cells[plant],a=analyze(s);
 assert.equal(c.type,'rubble');assert.equal(c.retiredPlant,'power');assert.equal(a.power.supply,0);assert.equal(a.jobs[plant],0);assert.equal(s.powerIncident,s.month);assert.equal(s.lastRenewal.cost,0);
});
test('A per-plant override wins over the global policy in both directions',()=>{
 const s=fresh();s.powerRenewal=false;s.cells[plant].renewal='on';s.cells[plant].age=599;step(s);assert.equal(s.cells[plant].age,0);assert.equal(s.cells[plant].renewal,'on');
 s.powerRenewal=true;s.cells[plant].renewal='off';s.cells[plant].age=599;step(s);assert.equal(s.cells[plant].type,'rubble');
});
test('Insufficient funds create a stopped plant, never a free renewal, and retry when funded',()=>{
 const s=fresh();s.cash=100;s.cells[plant].age=599;step(s);assert.equal(s.cells[plant].type,'rubble');assert.equal(s.lastRenewal.cost,0);
 s.cash=5000;step(s);assert.equal(s.cells[plant].type,'power');assert.equal(s.cells[plant].age,0);assert.equal(s.lastRenewal.cost,2400);
});
test('Several plants renew only within available funds, in deterministic map order',()=>{
 const s=fresh();build(s,[idx(13,16)],'solar');s.cells[plant].age=599;s.cells[idx(13,16)].age=599;s.cash=2500;
 step(s);assert.equal(s.cells[plant].type,'power');assert.equal(s.cells[idx(13,16)].type,'rubble');assert.equal(s.lastRenewal.cost,2400);
});
test('Renewal preferences persist, and legacy expired plants load as rubble and can renew',()=>{
 const s=fresh();s.powerRenewal=false;s.cells[plant].renewal='on';assert.deepEqual(deserialize(serialize(s)),s);
 const raw=JSON.parse(serialize(s));delete raw.powerRenewal;delete raw.lastRenewal;delete raw.powerIncident;for(const c of raw.cells.filter(Boolean)){delete c.renewal;delete c.retiredPlant;}raw.cells[plant].age=640;
 const loaded=deserialize(JSON.stringify(raw));assert.equal(loaded.cells[plant].type,'rubble');assert.equal(loaded.powerRenewal,true);step(loaded);assert.equal(loaded.cells[plant].type,'power');
});
test('Manual renewal preserves overrides; bulldozing cancels pending automatic rebuild',()=>{
 const s=fresh();s.cells[plant].renewal='off';s.cells[plant].age=599;s.powerRenewal=false;step(s);assert.ok(renewPlant(s,plant).ok);assert.equal(s.cells[plant].renewal,'off');
 s.cells[plant].age=599;s.cash=0;s.cells[plant].renewal='on';step(s);s.cash=5000;build(s,[plant],'bulldoze');step(s);assert.equal(s.cells[plant].type,null);assert.equal(s.lastRenewal.cost,0);
});
test('Warnings identify the plant before expiry and malformed settings are rejected',()=>{
 const s=fresh();s.cells[plant].age=587;step(s);assert.ok(s.events.some(e=>e.text.includes('12 個月')&&e.text.includes('13, 15')));
 for(const mutate of [s=>s.powerRenewal='yes',s=>s.cells[plant].renewal='yes',s=>s.cells[plant].retiredPlant='hospital']){const raw=JSON.parse(serialize(s));mutate(raw);assert.throws(()=>deserialize(JSON.stringify(raw)));}
});
