// Original score: Harbor Among Stars / 星港晨光. No recordings or external assets.
const BEAT=60/64, BAR=BEAT*8;
const CHORDS=[
 [50,57,61,66],[54,61,64,69],[45,52,59,61],[52,59,61,68],
 [47,54,57,61],[43,50,57,59],[50,57,61,64],[45,52,59,64]
];
const MELODY=[
 [78,null,73,null,76,null,69,null],[73,null,null,76,81,null,78,null],
 [76,null,71,null,73,null,null,69],[80,null,null,76,73,null,71,null],
 [73,null,78,null,null,76,69,null],[71,null,null,74,78,null,81,null],
 [78,null,76,null,73,null,null,69],[71,null,null,76,73,null,69,null]
];
const frequency=midi=>440*2**((midi-69)/12);

export class SpaceMusic{
 constructor({enabled=true,volume=.35,onchange=()=>{}}={}){
  this.enabled=enabled;this.volume=Number.isFinite(volume)?Math.max(0,Math.min(1,volume)):.35;
  this.onchange=onchange;this.context=null;this.timer=null;this.voices=new Set();
  this.activated=false;this.background=false;this.generation=0;this.beat=0;this.error='';
 }
 get playing(){return this.timer!==null&&this.context?.state==='running';}
 notify(){this.onchange();}
 initialize(){
  const Audio=globalThis.AudioContext||globalThis.webkitAudioContext;
  if(!Audio)throw new Error('這個瀏覽器不支援配樂播放。');
  const c=this.context=new Audio();
  this.master=c.createGain();this.master.gain.value=this.volume*.55;
  const compressor=c.createDynamicsCompressor();compressor.threshold.value=-12;compressor.knee.value=18;compressor.ratio.value=4;compressor.attack.value=.02;compressor.release.value=.6;
  this.bus=c.createGain();const tone=c.createBiquadFilter();tone.type='lowpass';tone.frequency.value=2300;tone.Q.value=.3;
  this.bus.connect(tone);tone.connect(compressor);compressor.connect(this.master);this.master.connect(c.destination);
  const delay=c.createDelay(2),feedback=c.createGain(),wet=c.createGain(),filter=c.createBiquadFilter();
  delay.delayTime.value=BEAT*.75;feedback.gain.value=.22;wet.gain.value=.2;filter.type='lowpass';filter.frequency.value=1350;
  this.bus.connect(delay);delay.connect(filter);filter.connect(feedback);feedback.connect(delay);filter.connect(wet);wet.connect(compressor);
  c.onstatechange=()=>this.notify();
 }
 async activate(){this.activated=true;return this.resume();}
 async resume(){
  if(!this.enabled||!this.activated||this.background)return;
  if(this.playing)return;
  const generation=++this.generation;
  try{
   if(!this.context)this.initialize();
   await this.context.resume();
   if(generation!==this.generation||!this.enabled||this.background)return;
   if(this.context.state!=='running')throw new Error('按「播放配樂」即可啟動聲音。');
   this.error='';
   // A system audio interruption may leave the scheduler alive. Reuse it.
   if(this.timer===null){this.nextTime=this.context.currentTime+.08;this.tick();this.timer=setInterval(()=>this.tick(),160);}
   this.notify();
  }catch(error){if(generation===this.generation){this.error=error.message||'按「播放配樂」重新啟動聲音。';this.notify();}}
 }
 suspend(){
  ++this.generation;
  if(this.timer!==null)clearInterval(this.timer);this.timer=null;
  const c=this.context;
  if(c){
   this.master.gain.cancelScheduledValues(c.currentTime);this.master.gain.setTargetAtTime(0,c.currentTime,.035);
   for(const voice of this.voices){try{voice.osc.stop();}catch{}voice.cleanup();}
   // Pause the entire audio graph, including the delay, when muted or in the background.
   void c.suspend().catch(()=>{});
  }
  this.beat=Math.floor(this.beat/8)*8;this.notify();
 }
 setEnabled(enabled){this.enabled=Boolean(enabled);if(this.enabled)void this.resume();else this.suspend();this.notify();}
 setBackground(hidden){this.background=hidden;if(hidden)this.suspend();else void this.resume();}
 setVolume(volume){
  if(!Number.isFinite(volume))return;
  this.volume=Math.max(0,Math.min(1,volume));
  if(this.context){const t=this.context.currentTime;this.master.gain.cancelScheduledValues(t);this.master.gain.setTargetAtTime(this.enabled?this.volume*.55:0,t,.08);}
  this.notify();
 }
 note(midi,time,duration,gain,{type='sine',attack=.05,pan=0,detune=0}={}){
  const c=this.context,osc=c.createOscillator(),envelope=c.createGain(),stereo=c.createStereoPanner();
  osc.type=type;osc.frequency.value=frequency(midi);osc.detune.value=detune;stereo.pan.value=pan;
  envelope.gain.setValueAtTime(0,time);envelope.gain.linearRampToValueAtTime(gain,time+attack);
  envelope.gain.setTargetAtTime(gain*.5,time+attack,Math.max(.1,duration*.2));
  envelope.gain.setTargetAtTime(0,time+duration*.65,Math.max(.08,duration*.1));
  envelope.gain.setValueAtTime(0,time+duration);
  osc.connect(envelope);envelope.connect(stereo);stereo.connect(this.bus);
  const voice={osc,cleanup:()=>{osc.disconnect();envelope.disconnect();stereo.disconnect();this.voices.delete(voice);}};this.voices.add(voice);
  osc.onended=voice.cleanup;
  osc.start(time);osc.stop(time+duration+.03);
 }
 tick(){
  const c=this.context;if(c.state!=='running')return;
  if(this.nextTime<c.currentTime-.2)this.nextTime=c.currentTime+.05;
  this.master.gain.setTargetAtTime(this.volume*.55,c.currentTime,.15);
  while(this.nextTime<c.currentTime+.5){
   const bar=Math.floor(this.beat/8)%16,part=this.beat%8,chord=CHORDS[bar%8],time=this.nextTime;
   if(part===0){
    chord.forEach((midi,i)=>{
     this.note(midi,time,BAR*1.12,.065,{attack:1.4,pan:(i-1.5)*.25,detune:-3});
     this.note(midi,time+.04,BAR*1.1,.023,{type:'triangle',attack:1.6,pan:(1.5-i)*.25,detune:3});
    });
    this.note(chord[0]-12,time,BAR,.105,{attack:.8});
   }
   if(part%2===0||bar>=8){
    const index=[0,2,1,3,2,0,3,1][part];
    this.note(chord[index]+12,time,BEAT*2.7,.043,{attack:.045,pan:part%4<2?-.28:.28});
   }
   const melody=MELODY[bar%8][part];
   if(melody!==null&&bar%4!==0)this.note(melody,time+.06,BEAT*3.2,.052,{attack:.22,pan:.12});
   this.beat=(this.beat+1)%128;this.nextTime+=BEAT;
  }
 }
}
