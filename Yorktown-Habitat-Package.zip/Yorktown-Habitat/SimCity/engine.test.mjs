import test from 'node:test';
import assert from 'node:assert/strict';
import {SIZE,TYPES,idx,terrain,residential} from './catalog.mjs';
import {createCity,analyze,step,build,undo,forecast,takeLoan,emergency,triggerDisaster,serialize,deserialize} from './engine.mjs';

const fresh=()=>{const s=createCity();s.disasters=false;return s;};
const advance=(s,n)=>{for(let i=0;i<n;i++)step(s);return analyze(s);};
function invariant(s,a=analyze(s)){
 assert.ok(Number.isFinite(s.cash));assert.ok(a.stats.employed<=a.stats.workers);assert.ok(a.stats.employed<=a.stats.jobs);
 assert.equal(s.cells.reduce((n,c)=>n+c.pop,0),a.stats.population);
 assert.equal(Array.from(a.filled).reduce((a,b)=>a+b,0),a.stats.employed);
 for(let i=0;i<s.cells.length;i++){const c=s.cells[i];assert.ok(!c.type||terrain(i));assert.ok(c.pop>=0&&Number.isInteger(c.pop));if(c.pop)assert.ok(residential(c.type));assert.ok(a.power.coverage[i]>=0&&a.power.coverage[i]<=1);assert.ok(a.water.coverage[i]>=0&&a.water.coverage[i]<=1);assert.ok(a.filled[i]<=a.jobs[i]);}
}
test('Starter city is a legal, connected, populated save',()=>{const s=fresh(),a=analyze(s);invariant(s,a);assert.equal(a.stats.population,120);assert.equal(a.stats.power,1);assert.equal(a.stats.water,1);assert.equal(a.stats.unemployment,0);assert.deepEqual(deserialize(serialize(s)),s);});
test('Ten-year economy reaches a stable playable surplus and conserves people and jobs',()=>{const s=fresh(),initial=s.cash;for(let i=0;i<120;i++){const before=s.cash;step(s);const h=s.history.at(-1);assert.ok(Math.abs(s.cash-before-h.net)<.011);invariant(s);}const a=analyze(s);assert.ok(a.stats.population>400);assert.ok(forecast(s,a).net>0);assert.ok(s.cash>initial);assert.ok(a.stats.congestion>1);});
test('Removing the only power plant shuts water production and drives residents away',()=>{const s=fresh();advance(s,24);const pop=analyze(s).stats.population;const r=build(s,[idx(12,14)],'bulldoze');assert.ok(r.ok);let a=analyze(s);assert.equal(a.power.supply,0);assert.equal(a.water.supply,0);assert.equal(a.stats.power,0);advance(s,8);assert.ok(analyze(s).stats.population<pop*.5);});
test('A disconnected power source cannot serve an isolated neighborhood',()=>{const s=createCity({starter:false});s.disasters=false;build(s,[idx(12,14)],'power');build(s,[idx(42,30)],'r');assert.equal(analyze(s).power.coverage[idx(42,30)],0);assert.ok(analyze(s).power.supply>0);});
test('Road demolition interrupts commuting independently from utilities',()=>{const s=fresh();advance(s,24);for(const c of s.cells)if(c.type==='road')c.type=null;const a=analyze(s);assert.equal(a.stats.power,1);assert.equal(a.stats.water,1);assert.equal(a.stats.employed,0);assert.equal(a.stats.unemployment,1);});
test('A finite supply network rations power instead of creating capacity',()=>{const s=fresh();s.funding.utilities=1;const a=analyze(s);assert.ok(a.stats.power>0&&a.stats.power<1);assert.ok(a.power.demand>a.power.supply);assert.ok(a.water.supply<60);});
test('Deleting water pipes cannot silently remove roads or electrical lines',()=>{const s=fresh();const before={...s.cells[idx(18,15)]};const r=build(s,[idx(18,15)],'erasePipe');assert.ok(r.ok);assert.equal(s.cells[idx(18,15)].type,before.type);assert.equal(s.cells[idx(18,15)].wire,true);assert.equal(s.cells[idx(18,15)].pipe,false);});
test('Blocked and unaffordable construction is atomic; open space outside the platform is rejected',()=>{const s=fresh(),text=serialize(s);assert.equal(build(s,[idx(12,14)],'hospital').ok,false);assert.equal(serialize(s),text);assert.equal(build(s,[0],'road').ok,false);assert.equal(serialize(s),text);s.cash=1;const before=serialize(s);assert.equal(build(s,[idx(40,18),idx(41,18)],'road').ok,false);assert.equal(serialize(s),before);});
test('Construction undo restores the complete tile and exact funds but cannot rewind simulation',()=>{const s=fresh(),before=serialize(s);const r=build(s,[idx(40,18),idx(41,18)],'road');assert.ok(r.ok);assert.ok(undo(s,r).ok);assert.equal(serialize(s),before);const second=build(s,[idx(40,18)],'road');step(s);assert.equal(undo(s,second).ok,false);});
test('Undeveloped zoning does not consume market demand before construction',()=>{const s=fresh(),before=analyze(s).stats.demand;const cells=[];for(let y=32;y<41;y++)for(let x=10;x<18;x++)if(terrain(idx(x,y)))cells.push(idx(x,y));assert.ok(build(s,cells,'C').ok);assert.equal(analyze(s).stats.demand.C,before.C);});
test('Undeveloped zoning carries utilities but consumes none until a building actually develops',()=>{
 const s=fresh(),before=analyze(s);const i=idx(15,16);assert.ok(build(s,[i],'I').ok);
 let a=analyze(s);assert.equal(a.power.demand,before.power.demand);assert.equal(a.water.demand,before.water.demand);assert.equal(a.power.coverage[i],1);assert.equal(a.water.coverage[i],1);
 s.cells[i].level=1;a=analyze(s);assert.ok(a.power.demand>before.power.demand);assert.ok(a.water.demand>before.water.demand);
});
test('A vertical tower connecting 510 planned zones cannot drain the inhabited city utility network',()=>{
 const s=fresh();s.funding.utilities=20;s.highPopulation=2000;s.cash=1e6;
 const planned=[];for(let y=10;y<=45;y++)for(let x=36;x<=50;x++)if(terrain(idx(x,y)))planned.push(idx(x,y));
 assert.equal(planned.length,510);assert.ok(build(s,planned,'I').ok);const before=analyze(s),pop=before.stats.population;
 assert.equal(before.stats.power,1);assert.equal(before.stats.water,1);
 assert.ok(build(s,[idx(35,15)],'arcology').ok);const connected=analyze(s);
 assert.equal(connected.stats.population,pop);assert.equal(connected.stats.power,1);assert.equal(connected.stats.water,1);assert.equal(connected.stats.jobs,before.stats.jobs);
 assert.ok(Math.abs(connected.power.demand-before.power.demand-4)<1e-8);assert.ok(Math.abs(connected.water.demand-before.water.demand-3)<1e-8);
 advance(s,6);assert.ok(analyze(s).stats.population>=pop);invariant(s);
 const restored=deserialize(serialize(s));assert.equal(analyze(restored).stats.population,analyze(s).stats.population);
});
test('Utility outage indicators do not turn healthy merely because the last resident has left',()=>{
 const s=fresh();for(const c of s.cells)c.pop=0;build(s,[idx(12,14)],'bulldoze');const a=analyze(s);assert.equal(a.stats.population,0);assert.ok(a.power.demand>0);assert.equal(a.stats.power,0);assert.equal(a.stats.water,0);
});
test('Higher taxes suppress demand and excessive residential taxes cause departure',()=>{const low=fresh(),high=fresh();advance(low,20);advance(high,20);const p=analyze(high).stats.population;high.tax.R=22;assert.ok(analyze(high).stats.demand.R<analyze(low).stats.demand.R);advance(high,12);advance(low,12);assert.ok(analyze(high).stats.population<p);assert.ok(analyze(high).stats.population<analyze(low).stats.population);});
test('Education and health funding has a lasting outcome beyond expense labels',()=>{const normal=fresh(),cut=fresh();cut.funding.school=0;cut.funding.hospital=0;advance(normal,120);advance(cut,120);assert.ok(normal.education>cut.education+20);assert.ok(normal.health>cut.health+20);assert.ok(forecast(cut).expenses.school===0);});
test('Cargo access affects real industrial jobs and removing the dock reduces them',()=>{const s=fresh();advance(s,20);const before=analyze(s);build(s,[idx(14,14)],'bulldoze');const after=analyze(s);const industry=s.cells.map((c,i)=>[c,i]).filter(([c])=>['i','I'].includes(c.type)).map(([,i])=>i);assert.ok(industry.reduce((n,i)=>n+after.jobs[i],0)<industry.reduce((n,i)=>n+before.jobs[i],0));assert.ok(industry.every(i=>after.freight[i]===0));});
test('Avenue upgrades reduce load ratios with the same simulated population',()=>{const s=fresh();advance(s,80);const before=analyze(s).stats.congestion;build(s,s.cells.flatMap((c,i)=>c.type==='road'?[i]:[]),'avenue');assert.ok(analyze(s).stats.congestion<before*.7);});
test('Rail without stations cannot carry commuters; connecting transfer stations opens real jobs',()=>{
 const s=createCity({starter:false});s.cash=1e6;s.disasters=false;const put=(x,y,t)=>build(s,[idx(x,y)],t);
 for(let x=10;x<=34;x++){put(x,14,'wire');put(x,14,'pipe');}
 for(let x=10;x<=15;x++)put(x,15,'road');for(let x=29;x<=34;x++)put(x,15,'road');for(let x=17;x<=27;x++)put(x,15,'rail');
 put(10,14,'power');put(11,14,'water');put(12,14,'R');s.cells[idx(12,14)].level=3;s.cells[idx(12,14)].pop=165;
 put(31,14,'dock');put(30,14,'I');s.cells[idx(30,14)].level=3;
 const before=analyze(s);assert.equal(before.filled[idx(30,14)],0);put(16,15,'station');put(28,15,'station');
 const after=analyze(s);assert.ok(after.filled[idx(30,14)]>0);assert.ok(after.stats.employed>before.stats.employed);assert.ok(after.traffic[idx(22,15)]>0);invariant(s,after);
});
test('A bus depot improves its own road component, not an unrelated disconnected road',()=>{
 const s=fresh();build(s,[idx(40,35)],'road');const before=analyze(s);build(s,[idx(15,14)],'bus');const after=analyze(s);
 assert.ok(after.roadCapacity[idx(18,15)]>before.roadCapacity[idx(18,15)]);assert.equal(after.roadCapacity[idx(40,35)],before.roadCapacity[idx(40,35)]);
});
test('Pollution ordinance reduces pollution and has a real monthly expense',()=>{const s=fresh();const before=analyze(s).pollution[idx(32,14)];s.policies.green=true;assert.ok(analyze(s).pollution[idx(32,14)]<before*.7);assert.ok(forecast(s).expenses.policies>0);});
test('Land value overlays cover unzoned land and respond to new parks',()=>{const s=fresh(),i=idx(13,16),before=analyze(s).landValue[i];assert.equal(s.cells[i].type,null);assert.ok(before>0);assert.ok(build(s,[idx(14,16)],'park').ok);assert.ok(analyze(s).landValue[i]>before);});
test('Bonds produce funds, monthly interest, amortization and a strict issue limit',()=>{const s=fresh(),cash=s.cash;assert.ok(takeLoan(s).ok);assert.equal(s.cash,cash+15000);assert.equal(forecast(s).expenses.debt,185);step(s);assert.equal(s.loans[0].balance,14875);assert.equal(s.loans[0].months,119);deserialize(serialize(s));advance(s,119);assert.equal(s.loans.length,0);assert.ok(takeLoan(s).ok);assert.ok(takeLoan(s).ok);assert.ok(takeLoan(s).ok);assert.equal(takeLoan(s).ok,false);});
test('50-year plant retirement stops supply and rebuilding restores it',()=>{const s=fresh();s.powerRenewal=false;s.cells[idx(12,14)].age=599;step(s);assert.equal(analyze(s).power.supply,0);build(s,[idx(12,14)],'bulldoze');build(s,[idx(12,14)],'power');assert.ok(analyze(s).power.supply>0);});
test('Emergency responders spend funds and suppress an ongoing fire',()=>{const s=fresh();s.funding.fire=0;const r=triggerDisaster(s,'fire');assert.ok(r.ok);assert.ok(s.cells.some(c=>c.fire));const cash=s.cash;assert.ok(emergency(s).ok);assert.equal(s.cash,cash-500);advance(s,3);assert.ok(!s.cells.some(c=>c.fire));});
test('Meteor damage destroys actual buildings and conduits',()=>{const s=fresh();assert.ok(triggerDisaster(s,'meteor').ok);const rubble=s.cells.filter(c=>c.type==='rubble');assert.ok(rubble.length>0);assert.ok(rubble.every(c=>!c.wire&&!c.pipe&&c.pop===0));invariant(s);});
test('Bankruptcy pauses simulation and bond rescue restores play',()=>{const s=fresh();s.cash=-19999;step(s);assert.ok(s.insolvent);const m=s.month;step(s);assert.equal(s.month,m);assert.ok(takeLoan(s).ok);assert.equal(s.insolvent,false);step(s);assert.equal(s.month,m+1);});
test('A save reload reproduces deterministic future evolution, not just visible counters',()=>{const s=fresh();s.disasters=true;advance(s,46);takeLoan(s);const restored=deserialize(serialize(s));advance(s,36);advance(restored,36);assert.equal(serialize(restored),serialize(s));});
test('Malformed saves reject invalid cells, money, loans and incompatible versions',()=>{const s=fresh();for(const change of [x=>x.version=99,x=>x.cash='Infinity',x=>x.cells[0].type='r',x=>x.cells[100].type='unknown',x=>x.cells[100].pop=100,x=>x.loans=[{balance:15000,principal:0,months:120}],x=>x.tax.R=-2]){const raw=JSON.parse(serialize(s));raw.cells=raw.cells.map((c,i)=>c||{...s.cells[i]});change(raw);assert.throws(()=>deserialize(JSON.stringify(raw)));}assert.throws(()=>deserialize('{'));});
test('Full map capacity and high-density cities preserve invariants without unbounded state',()=>{const s=createCity({starter:false});s.cash=1e7;s.disasters=false;for(let y=6;y<50;y++)for(let x=6;x<50;x++){const i=idx(x,y);if(!terrain(i))continue;const t=y%3===0?'avenue':x%7===0?'I':x%5===0?'C':'R';build(s,[i],t);if(['R','C','I'].includes(t))s.cells[i].level=1;}for(const [x,y,t] of [[18,12,'power'],[19,12,'water'],[20,12,'dock'],[40,36,'power'],[39,36,'water'],[38,36,'dock']]){build(s,[idx(x,y)],'bulldoze');build(s,[idx(x,y)],t);}advance(s,36);invariant(s);assert.ok(analyze(s).stats.population>500);assert.ok(s.history.length<=240);deserialize(serialize(s));});
