import test from 'node:test';
import assert from 'node:assert/strict';
import {SIZE,CELL_COUNT,idx,neighbors,terrain,INTERIORS,SECTORS,sectorX} from './catalog.mjs';
import {surface,moveWalker,canWalk,roadRoute} from './habitat.mjs';
import {createCity,build,analyze,step,serialize,deserialize,manageBuilding,buildingReport} from './engine.mjs';
const fresh=()=>{const s=createCity({starter:false});s.cash=1e7;s.disasters=false;return s;};
const put=(s,x,y,t)=>assert.ok(build(s,[idx(x,y)],t).ok);
test('All 19,296 tiles are legal and all eight sectors accept construction',()=>{
 const s=fresh();assert.equal(s.cells.filter((c,i)=>terrain(i)).length,19296);
 for(let n=0;n<SECTORS.length;n++){const x=sectorX(n);put(s,x,25,'power');assert.equal(s.cells[idx(x,25)].type,'power');}
 assert.ok(neighbors(idx(0,20)).includes(idx(SIZE-1,20)));assert.equal(terrain(CELL_COUNT),false);
});
test('Walking and routes cross the ring seam continuously',()=>{
 const s=fresh();for(const x of [SIZE-2,SIZE-1,0,1])put(s,x,20,'road');assert.equal(roadRoute(s.cells,idx(SIZE-2,20),idx(1,20)).length,4);
 const p={u:SIZE-28-.1,v:20-27.5};moveWalker(s.cells,p,.6,0);assert.ok(p.u< -27);assert.ok(canWalk(s.cells,p.u,p.v));
 const a=surface(SIZE-28-.001,0),b=surface(-28+.001,0);assert.ok(Math.hypot(...a.map((v,i)=>v-b[i]))<.003);
});
test('Seam roads carry utilities, jobs and nearby public services',()=>{
 const s=fresh();for(const x of [SIZE-4,SIZE-3,SIZE-2,SIZE-1,0,1,2,3])put(s,x,20,'avenue');
 put(s,SIZE-4,19,'power');put(s,SIZE-3,19,'water');put(s,SIZE-2,19,'R');Object.assign(s.cells[idx(SIZE-2,19)],{level:3,pop:165});put(s,0,19,'dock');put(s,1,19,'I');s.cells[idx(1,19)].level=2;put(s,2,19,'hospital');
 const a=analyze(s);assert.equal(a.power.coverage[idx(1,19)],1);assert.equal(a.water.coverage[idx(1,19)],1);assert.ok(a.filled[idx(1,19)]>0);assert.ok(a.services.hospital[idx(SIZE-2,19)]>30);
 build(s,[idx(SIZE-1,20),idx(0,20)],'bulldoze');const broken=analyze(s);assert.equal(broken.power.coverage[idx(1,19)],0);assert.equal(broken.filled[idx(1,19)],0);
});
test('Old curved saves migrate with their buildings, finances and population',()=>{
 const s=createCity();s.cells[idx(12,14)].age=550;const raw={...s,version:2,cells:Array.from({length:3136},(_,i)=>{const c={...s.cells[idx(i%56,Math.floor(i/56))]};delete c.enabled;delete c.upgrade;return c;})};
 const restored=deserialize(JSON.stringify(raw));assert.equal(restored.cells[idx(12,14)].age,550);assert.equal(restored.cash,s.cash);assert.equal(analyze(restored).stats.population,120);assert.equal(restored.cells[idx(400,20)].type,null);
 const copy=deserialize(serialize(restored));step(restored);step(copy);assert.equal(serialize(copy),serialize(restored));
});
test('Building upgrades cost money and change supply and upkeep; pause stops production',()=>{
 const s=createCity(),i=idx(12,14),before=s.cash;assert.ok(manageBuilding(s,i,'upgrade').ok);assert.equal(s.cash,before-1440);assert.equal(analyze(s).power.supply,7500);assert.equal(buildingReport(s,analyze(s),i).upkeep,48);
 manageBuilding(s,i,'toggle');assert.equal(analyze(s).power.supply,0);assert.ok(Math.abs(buildingReport(s,analyze(s),i).upkeep-7.2)<1e-9);
 manageBuilding(s,i,'toggle');manageBuilding(s,i,'upgrade');const cash=s.cash;assert.equal(manageBuilding(s,i,'upgrade').ok,false);assert.equal(s.cash,cash);assert.deepEqual(deserialize(serialize(s)),s);
});
test('Life support and cooling capacity require connected utilities',()=>{
 const s=createCity(),before=analyze(s);put(s,100,20,'life');put(s,101,20,'radiator');const remote=analyze(s);assert.equal(remote.space.air.supply,before.space.air.supply);assert.equal(remote.space.heat.supply,before.space.heat.supply);
 put(s,15,14,'life');put(s,16,16,'radiator');const connected=analyze(s);assert.ok(connected.space.air.supply>before.space.air.supply+2000);assert.ok(connected.space.heat.supply>before.space.heat.supply+6000);
 manageBuilding(s,idx(15,14),'toggle');assert.equal(analyze(s).space.air.supply,before.space.air.supply);
});
test('Ten important room types use their actual building and close after fire or demolition',()=>{
 const s=createCity(),i=idx(12,14);assert.equal(Object.keys(INTERIORS).length,10);assert.equal(buildingReport(s,analyze(s),i).interior,'融合控制室');s.cells[i].fire=3;assert.equal(buildingReport(s,analyze(s),i).interior,null);build(s,[i],'bulldoze');assert.equal(buildingReport(s,analyze(s),i),null);
});
test('Upgraded housing capacity and management survive a validated save round trip',()=>{
 const s=createCity();s.highPopulation=2000;s.cash=1e6;put(s,35,15,'arcology');const i=idx(35,15);manageBuilding(s,i,'upgrade');manageBuilding(s,i,'upgrade');s.cells[i].pop=750;
 assert.equal(buildingReport(s,analyze(s),i).capacity,750);assert.equal(deserialize(serialize(s)).cells[i].pop,750);const raw=JSON.parse(serialize(s));raw.cells[i].upgrade=3;assert.throws(()=>deserialize(JSON.stringify(raw)));
});
test('Compact full-arm saves fit two browser slots and preserve every parcel',()=>{
 const s=fresh();for(let i=0;i<s.cells.length;i++)if(terrain(i))Object.assign(s.cells[i],{type:'R',level:2,pop:10,wire:true,pipe:true,enabled:true,upgrade:1});
 const text=serialize(s,{compact:true});assert.ok(text.length<1100000);const copy=deserialize(text);assert.deepEqual(copy.cells,s.cells);assert.equal(copy.cash,s.cash);
});
test('Capacity shortages reduce operation and connected life support and radiators restore it',()=>{
 const s=fresh();for(let x=100;x<134;x++)put(s,x,20,'avenue');
 put(s,100,21,'power');put(s,101,21,'water');for(let x=100;x<130;x++){put(s,x,19,'R');Object.assign(s.cells[idx(x,19)],{level:3,pop:165});}
 const before=analyze(s);assert.equal(before.stats.power,1);assert.equal(before.stats.water,1);assert.ok(before.stats.oxygen<1);assert.ok(before.stats.cooling<1);
 put(s,102,21,'life');put(s,103,21,'radiator');const after=analyze(s);assert.equal(after.stats.oxygen,1);assert.equal(after.stats.cooling,1);assert.ok(after.operational[idx(100,19)]>before.operational[idx(100,19)]);
});
