import * as THREE from '../YorktownPreview/three.module.js';
import {SIZE,HEIGHT,CELL_COUNT,district,TYPES,DECK,wrapX,deltaX,neighbors,INTERIORS,terrain,xy,idx,isRoad,isTransport,zoneOf,residential} from './catalog.mjs';

import {surface,localPoint,tileAt,canWalk,nearestWalkable,moveWalker,solid,roadRoute} from './habitat.mjs';
import {createStation} from './station.mjs';
import {InteriorRoom} from './interior.mjs';

export class CityView{
 constructor(host,callbacks){
  this.cb=callbacks;this.host=host;this.mode='build';this.flyer={u:-8,v:-10,h:8,yaw:Math.PI/2,pitch:-.2};this.interiorTile=-1;this.keys={};this.walker={u:-9.5,v:-12.5,jump:0,velocity:0,yaw:Math.PI/2,pitch:-.08};this.signatures=new Map();this.growth=new Map();this.growing=[];this.people=[];this.streetClock=0;this.simulationSpeed=0;this.lastFrame=performance.now();this.pitch=.84;this.yaw=-.50;this.distance=37;this.target=new THREE.Vector3(-8,0,-9);this.pointers=new Map();this.tool='inspect';this.overlay='normal';this.preview=[];
  this.scene=new THREE.Scene();this.scene.background=new THREE.Color(0x050b16);this.scene.fog=new THREE.FogExp2(0x071021,.0009);
  this.camera=new THREE.PerspectiveCamera(48,1,.025,1400);
  this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.3;
  this.renderer.domElement.setAttribute('aria-label','Yorktown 城市地圖；選擇工具後點選或拖曳建造');host.append(this.renderer.domElement);
  this.scene.add(new THREE.AmbientLight(0xa3c7d9,.9));this.scene.add(new THREE.HemisphereLight(0xc4eaff,0x293448,2.8));const sun=new THREE.DirectionalLight(0xffdfb4,3);sun.position.set(-25,50,10);this.scene.add(sun);
  const rim=new THREE.DirectionalLight(0x73b8ff,2);rim.position.set(30,20,-30);this.scene.add(rim);
  this.world=new THREE.Group();this.scene.add(this.world);this.buildings=new THREE.Group();this.scene.add(this.buildings);
  this.box=new THREE.BoxGeometry(1,1,1);this.mat=new THREE.MeshStandardMaterial({color:0xffffff,roughness:.7,metalness:.15});
  this.valid=Array.from({length:CELL_COUNT},(_,i)=>i).filter(terrain);this.floor=new THREE.InstancedMesh(this.box,new THREE.MeshBasicMaterial({color:0xffffff}),this.valid.length);this.floor.userData.ground=true;this.world.add(this.floor);
  this.dummy=new THREE.Object3D();this.color=new THREE.Color();
  this.valid.forEach((i,n)=>{const [x,y]=xy(i);this.matrix(this.floor,n,x,-.37,y,1.005,.86,1.005);this.floor.setColorAt(n,this.color.setHex(0x263f51));});
  this.floor.instanceMatrix.needsUpdate=true;
  this.station=createStation(this.scene);
  this.addRails();
  const stars=[];for(let i=0;i<1400;i++){const a=i*2.399963,b=Math.acos(1-2*(i+.5)/1400),r=550+Math.sin(i*7)*30;stars.push(Math.cos(a)*Math.sin(b)*r,Math.cos(b)*r,Math.sin(a)*Math.sin(b)*r);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(stars,3));this.scene.add(new THREE.Points(g,new THREE.PointsMaterial({color:0xc4dff5,size:.3,transparent:true,opacity:.7})));
  const nebula=new THREE.Mesh(new THREE.SphereGeometry(38,32,20),new THREE.MeshBasicMaterial({color:0x0b2341}));nebula.position.set(75,-44,-105);this.scene.add(nebula);
  const planetRim=new THREE.Mesh(new THREE.TorusGeometry(38,.3,5,100),new THREE.MeshBasicMaterial({color:0x355c7a}));planetRim.position.copy(nebula.position);this.scene.add(planetRim);
  this.highlight=new THREE.InstancedMesh(this.box,new THREE.MeshBasicMaterial({color:0xc9fff2,transparent:true,opacity:.4,depthWrite:false}),CELL_COUNT);this.highlight.count=0;this.scene.add(this.highlight);
  this.selection=new THREE.Mesh(new THREE.BoxGeometry(1.04,.04,1.04),new THREE.MeshBasicMaterial({color:0xe0fff7,wireframe:true}));this.selection.visible=false;this.scene.add(this.selection);
  this.ray=new THREE.Raycaster();this.plane=new THREE.Plane(new THREE.Vector3(0,1,0),0);this.hit=new THREE.Vector3();
  this.ships=[];for(let i=0;i<7;i++){const ship=new THREE.Mesh(new THREE.ConeGeometry(.16,.6,4),new THREE.MeshStandardMaterial({color:0xbfe9ff,emissive:0x245f89}));ship.rotation.z=Math.PI/2;this.scene.add(ship);this.ships.push(ship);}
  this.setupPeople();this.bind();this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(host);this.resize();this.animate();
 }
 matrix(mesh,n,x,h,y,sx,sy,sz){const u=x-27.5;this.dummy.position.set(...surface(u,y-27.5,h));this.dummy.scale.set(sx,sy,sz);this.dummy.rotation.set(0,0,u/DECK.radius);this.dummy.updateMatrix();mesh.setMatrixAt(n,this.dummy.matrix);}
 cameraUpdate(){
  if(this.mode==='walk'){
   const w=this.walker,a=w.u/DECK.radius,eye=new THREE.Vector3(...surface(w.u,w.v,.28+w.jump));
   const forward=new THREE.Vector3(Math.cos(a)*Math.sin(w.yaw),Math.sin(a)*Math.sin(w.yaw),-Math.cos(w.yaw));
   this.camera.up.set(-Math.sin(a),Math.cos(a),0);forward.multiplyScalar(Math.cos(w.pitch)).addScaledVector(this.camera.up,Math.sin(w.pitch));this.camera.position.copy(eye);this.camera.lookAt(eye.clone().add(forward));
  }else if(this.mode==='interior'){
   const p=this.room.position;this.camera.up.set(0,1,0);this.camera.position.set(p.x,1.65,p.z);this.camera.lookAt(p.x+Math.sin(p.yaw)*Math.cos(p.pitch),1.65+Math.sin(p.pitch),p.z-Math.cos(p.yaw)*Math.cos(p.pitch));
  }else if(this.mode==='fly'){
   const w=this.flyer,a=w.u/DECK.radius,eye=new THREE.Vector3(...surface(w.u,w.v,w.h));this.camera.up.set(-Math.sin(a),Math.cos(a),0);
   const forward=new THREE.Vector3(Math.cos(a)*Math.sin(w.yaw),Math.sin(a)*Math.sin(w.yaw),-Math.cos(w.yaw));forward.multiplyScalar(Math.cos(w.pitch)).addScaledVector(this.camera.up,Math.sin(w.pitch));this.camera.position.copy(eye);this.camera.lookAt(eye.clone().add(forward));
  }else if(this.mode==='build'){
   const [u,v]=localPoint(this.target.x,this.target.y,this.target.z),angle=u/DECK.radius;
   this.target.set(...surface(u,v));const up=new THREE.Vector3(-Math.sin(angle),Math.cos(angle),0),tangent=new THREE.Vector3(Math.cos(angle),Math.sin(angle),0);
   this.camera.up.copy(up);this.camera.position.copy(this.target).addScaledVector(up,this.distance*Math.sin(this.pitch)).addScaledVector(tangent,Math.sin(this.yaw)*this.distance*Math.cos(this.pitch));this.camera.position.z+=Math.cos(this.yaw)*this.distance*Math.cos(this.pitch);this.camera.lookAt(this.target);
  }else{this.camera.up.set(0,1,0);this.camera.position.set(this.target.x+Math.sin(this.yaw)*this.distance*Math.cos(this.pitch),this.target.y+this.distance*Math.sin(this.pitch),this.target.z+Math.cos(this.yaw)*this.distance*Math.cos(this.pitch));this.camera.lookAt(this.target);}

 }
 resize(){const w=this.host.clientWidth,h=this.host.clientHeight;this.renderer.setSize(w,h,false);this.camera.aspect=w/Math.max(1,h);this.camera.updateProjectionMatrix();this.cameraUpdate();}
 pick(clientX,clientY){
  if(this.mode==='interior')return -1;
  const r=this.renderer.domElement.getBoundingClientRect();this.ray.setFromCamera(new THREE.Vector2((clientX-r.left)/r.width*2-1,1-(clientY-r.top)/r.height*2),this.camera);
  const hits=this.ray.intersectObjects([this.floor,...this.buildings.children],false);if(!hits.length)return -1;
  const hit=hits[0];if(this.mode==='walk'&&hit.distance>9)return -1;
  return hit.object===this.floor?this.valid[hit.instanceId]:hit.object.userData.tiles?.[hit.instanceId]??-1;
 }
 setTool(tool){if(['overview','fly','interior'].includes(this.mode)&&tool!=='inspect')this.setMode('build');this.tool=tool;this.renderer.domElement.style.cursor=tool==='inspect'?'grab':'crosshair';this.preview=[];this.setPreview([]);}
 showSelection(i){this.selection.visible=i>=0;if(i>=0){const [x,y]=xy(i);this.selection.position.set(...surface(x-27.5,y-27.5,.07));this.selection.rotation.z=(x-27.5)/DECK.radius;}}
 focus(i){const [x,y]=xy(i);this.setMode('build');this.target.set(...surface(x-27.5,y-27.5));this.distance=18;this.cameraUpdate();}
 home(){this.setMode('build');this.target.set(...surface(-8, -10));this.distance=37;this.pitch=.84;this.cameraUpdate();}
 overview(){this.setMode('overview');this.target.set(0,DECK.radius,0);this.distance=330;this.pitch=.35;this.yaw=-.6;this.cameraUpdate();}
 zoom(delta){if(this.mode==='interior')return;if(this.mode==='fly'){this.flyer.h=Math.max(1,Math.min(65,this.flyer.h*delta));this.cameraUpdate();return;}if(this.mode==='walk')this.setMode('build');this.distance=Math.max(3,Math.min(this.mode==='overview'?450:90,this.distance*delta));this.cameraUpdate();}
 rotate(){if(this.mode==='interior')this.room.position.yaw+=Math.PI/4;else if(this.mode==='fly')this.flyer.yaw+=Math.PI/4;else if(this.mode==='walk')this.walker.yaw+=Math.PI/4;else this.yaw+=Math.PI/4;this.cameraUpdate();}
 line(a,b){if(a<0||b<0||['overview','fly','interior'].includes(this.mode))return [];if(this.mode==='walk')return [b];const [x,y]=xy(a),[bx,v]=xy(b),u=x+deltaX(x,bx),list=[];if(TYPES[this.tool]?.group==='zone'||this.tool==='bulldoze'){for(let j=Math.min(y,v);j<=Math.max(y,v);j++)for(let i=Math.min(x,u);i<=Math.max(x,u);i++)if(terrain(idx(wrapX(i),j)))list.push(idx(wrapX(i),j));}
  else if(['road','avenue','rail','wire','pipe','eraseWire','erasePipe'].includes(this.tool)){for(let i=Math.min(x,u);i<=Math.max(x,u);i++)if(terrain(idx(wrapX(i),y)))list.push(idx(wrapX(i),y));for(let j=Math.min(y,v);j<=Math.max(y,v);j++)if(terrain(idx(wrapX(u),j)))list.push(idx(wrapX(u),j));}
  else list.push(b);return [...new Set(list)];}
 setPreview(indices){this.highlight.count=indices.length;indices.forEach((i,n)=>{const [x,y]=xy(i);this.matrix(this.highlight,n,x,.07,y,.98,.02,.98);});this.highlight.instanceMatrix.needsUpdate=true;this.cb.preview?.(indices);}
 bind(){const el=this.renderer.domElement;
  document.addEventListener('keydown',e=>{if(document.querySelector('dialog[open]')||/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;if(e.code==='KeyE'){e.preventDefault();if(this.mode==='interior')this.setMode('walk');else this.enterNearby();return;}if(e.code==='KeyM'&&this.mode==='interior'){this.cb.manage?.(this.interiorTile);return;}if(e.code==='KeyG'){e.preventDefault();this.setMode(this.mode==='fly'?'build':'fly');return;}if(e.code==='KeyF'){e.preventDefault();this.setMode(this.mode==='walk'?'build':'walk');return;}if(['walk','fly','interior'].includes(this.mode)&&['KeyQ','KeyC','KeyW','KeyA','KeyS','KeyD','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Space','ShiftLeft','ShiftRight'].includes(e.code)){e.preventDefault();if(this.mode==='walk'&&e.code==='Space'&&!e.repeat&&this.walker.jump===0)this.walker.velocity=1.35;this.keys[e.code]=true;if(!e.repeat){if(this.mode==='walk')this.walk(1/60);else if(this.mode==='fly')this.fly(1/60);else if(this.mode==='interior')this.walkInterior(1/60);}}});
  document.addEventListener('keyup',e=>delete this.keys[e.code]);addEventListener('blur',()=>{this.keys={};this.pointers.clear();this.start=null;});document.addEventListener('visibilitychange',()=>{this.keys={};this.lastFrame=performance.now();});
 el.addEventListener('contextmenu',e=>e.preventDefault());
  el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(this.pointers.size>1){this.gesture=true;this.setPreview([]);return;}this.gesture=false;this.start={x:e.clientX,y:e.clientY,i:this.pick(e.clientX,e.clientY),lastX:e.clientX,lastY:e.clientY,button:e.button};this.moved=false;if(this.tool!=='inspect'&&e.button===0)this.setPreview(this.line(this.start.i,this.start.i));});
  el.addEventListener('pointermove',e=>{
   const point=this.pointers.get(e.pointerId);if(!point){const i=this.pick(e.clientX,e.clientY);this.cb.hover?.(i);if(this.tool!=='inspect')this.setPreview(i<0?[]:[i]);return;}
   const old={...point};point.x=e.clientX;point.y=e.clientY;
   if(this.pointers.size===2){const other=[...this.pointers.entries()].find(([id])=>id!==e.pointerId)[1],before=Math.hypot(old.x-other.x,old.y-other.y),after=Math.hypot(point.x-other.x,point.y-other.y);if(after>10)this.zoom(before/after);this.pan((point.x-old.x)*.5,(point.y-old.y)*.5);return;}
   if(this.gesture||!this.start)return;
   const dx=e.clientX-this.start.lastX,dy=e.clientY-this.start.lastY;this.start.lastX=e.clientX;this.start.lastY=e.clientY;
   if(Math.hypot(e.clientX-this.start.x,e.clientY-this.start.y)>5)this.moved=true;
   if(this.tool==='inspect'||this.start.button!==0)this.pan(dx,dy);else this.setPreview(this.line(this.start.i,this.pick(e.clientX,e.clientY)));
  });
  el.addEventListener('pointerup',e=>{this.pointers.delete(e.pointerId);if(!this.gesture&&this.start){const i=this.pick(e.clientX,e.clientY);if(this.tool==='inspect'&&!this.moved&&i>=0)this.cb.select(i);else if(this.tool!=='inspect'&&this.start.button===0)this.cb.build(this.line(this.start.i,i));}if(!this.pointers.size){this.start=null;this.gesture=false;}this.setPreview([]);});
  el.addEventListener('pointercancel',e=>{this.pointers.delete(e.pointerId);this.start=null;this.gesture=true;this.setPreview([]);});
  el.addEventListener('pointerleave',()=>{if(!this.pointers.size)this.setPreview([]);});
  el.addEventListener('wheel',e=>{e.preventDefault();this.zoom(Math.exp(e.deltaY*.001));},{passive:false});
 }
 pan(dx,dy){if(['walk','fly','interior'].includes(this.mode)){const p=this.mode==='walk'?this.walker:this.mode==='fly'?this.flyer:this.room.position;p.yaw+=dx*.004;p.pitch=Math.max(-1.3,Math.min(1.3,p.pitch-dy*.004));this.cameraUpdate();return;}if(this.mode==='overview'){this.yaw-=dx*.004;this.pitch=Math.max(-.3,Math.min(1.4,this.pitch+dy*.003));this.cameraUpdate();return;}const k=this.distance*.0009,[u,v]=localPoint(this.target.x,this.target.y,this.target.z);this.target.set(...surface(u-dx*Math.cos(this.yaw)*k-dy*Math.sin(this.yaw)*k/Math.sin(this.pitch),Math.max(-19,Math.min(15,v+dx*Math.sin(this.yaw)*k-dy*Math.cos(this.yaw)*k/Math.sin(this.pitch)))));this.cameraUpdate();}

 update(s,a,overlay='normal'){
  this.lodPosition=this.camera.position.clone();this.lodTime=performance.now();this.overlay=overlay;this.state=s;this.analysis=a;this.growing=[];const first=this.signatures.size===0,now=performance.now();for(const i of this.valid){const c=s.cells[i],signature=`${c.type}:${c.level}`;if(!first&&this.signatures.get(i)!==signature&&solid(c))this.growth.set(i,now);if(!solid(c))this.growth.delete(i);this.signatures.set(i,signature);}if(this.mode==='walk')this.ensureWalkable();this.updatePeople();if(this.mode==='interior'){const c=s.cells[this.interiorTile];if(!c||c.type!==this.room.type||c.fire||!c.level)this.setMode('walk');else this.room.update(c,a,this.interiorTile,s.month);}
  for(const child of [...this.buildings.children]){this.buildings.remove(child);if(child.isInstancedMesh)child.dispose();if(child.material!==this.mat)child.material.dispose();}
  const pieces=[],lights=[],lines=[];let tile=-1;const add=(x,y,h,sx,sy,sz,color)=>pieces.push({x,y,h,sx,sy,sz,color,tile});
  this.valid.forEach((i,n)=>{
   tile=i;const c=s.cells[i],def=TYPES[c.type],[x,y]=xy(i);let color=(x+y)%2?0x263e50:0x2d485a;if(y===8||y===43)color=0x477581;if(x%67===0)color=0x3b6677;
   if(c.type)color=isTransport(c.type)?def.color:zoneOf(c.type)?def.color:0x39556b;
   if(overlay!=='normal'){
    let v=0;
    if(overlay==='power'){v=a.power.coverage[i];color=v>.9?0x4dddc0:v>0?0xc79140:0x402f41;}
    if(overlay==='water'){v=a.water.coverage[i];color=v>.9?0x59bde9:v>0?0xbdab59:0x402f41;}
    if(overlay==='oxygen'||overlay==='cooling'){v=a.space[overlay][i];color=v>.95?(overlay==='oxygen'?0x58d8a9:0x79c8e9):v>0?0xd6a756:0x553345;}
    if(overlay==='traffic'){v=a.traffic[i]/Math.max(1,a.roadCapacity[i]);color=isTransport(c.type)?v>1?0xec6f61:v>.65?0xe5b361:0x6bd2b6:0x243845;}
    if(overlay==='pollution'){v=a.pollution[i]/100;this.color.setHSL(.46*(1-Math.min(1,v)),.45,.28);color=this.color.getHex();}
    if(overlay==='value'){v=a.landValue[i]/100;this.color.setHSL(.50,.40,.15+v*.4);color=this.color.getHex();}
    if(['fire','police','school','hospital'].includes(overlay)){v=a.services[overlay][i]/100;color=v>.5?0x5dd5b0:v>.15?0xc4b263:0x553c47;}
   }
   this.floor.setColorAt(n,this.color.setHex(color));
   if(isRoad(c.type)){
    const horiz=isRoad(s.cells[idx(wrapX(x-1),y)]?.type)||isRoad(s.cells[idx(wrapX(x+1),y)]?.type);
    const vert=(y>0&&isRoad(s.cells[i-SIZE]?.type))||(y<HEIGHT-1&&isRoad(s.cells[i+SIZE]?.type));
    if(horiz||!vert)add(x,y,.079,.55,.015,.025,0xc2c7b2);if(vert)add(x,y,.08,.025,.015,.55,0xc2c7b2);
   }else if(c.type==='rail'){const horiz=s.cells[idx(wrapX(x-1),y)]?.type==='rail'||s.cells[idx(wrapX(x+1),y)]?.type==='rail';for(const offset of [-.15,.15])add(x+(horiz?0:offset),y+(horiz?offset:0),.11,horiz?.9:.045,.07,horiz?.045:.9,0xb8d4df);}
   else if(c.type==='park'){
    for(let j=0;j<3;j++){const u=x+(j-1)*.22,v=y+Math.sin(i+j)*.16;add(u,v,.24,.05,.3,.05,0x778571);add(u,v,.45,.25,.4,.25,0x64bc94);}
   }else if(c.type==='solar'){
    add(x,y,.28,.82,.16,.74,0x4973ba);for(let j=-1;j<=1;j++)add(x+j*.24,y,.37,.012,.015,.65,0x8ecdf3);
   }else if(c.type==='rubble'){
    for(let j=0;j<3;j++)add(x+(j-1)*.23,y+Math.sin(i+j)*.16,.16,.22,.2,.3,0x655c64);
   }else if(c.type&&c.level){
    const zone=zoneOf(c.type);let h=zone?(.2+c.level*.27+(c.type.toUpperCase()===c.type?.45:0)):.7;
    h*=1+(c.upgrade||0)*.12;if(c.type==='arcology')h=3.8;if(['power','water','dock','airport'].includes(c.type))h=1.05;
    const far=this.mode==='overview'||this.camera.position.distanceTo(new THREE.Vector3(...surface(x-27.5,y-27.5)))>55;
    const baseColor=zone==='R'?0xbcd7d8:zone==='C'?0x81bbd6:zone==='I'?0xc3b295:def.color;
    add(x,y,.09+h/2,.7,h,.7,c.fire?0xd7694c:baseColor);add(x,y,h+.12,.77,.06,.77,def.color);
    if(!far){
    if(zone==='R'||zone==='C'){
     if(c.pop>0||a.filled[i]>0)for(let j=1;j<=Math.ceil(h/.3);j++)lights.push({tile:i,x:x-.356,y,h:.12+j*.23,sx:.014,sy:.055,sz:.45,color:zone==='R'?0xf3dfa6:0x95efff});
     if(c.pop>0||a.filled[i]>0)for(let j=1;j<=Math.ceil(h/.3);j++)for(const side of [-1,1])for(const offset of [-.22,0,.22])lights.push({tile:i,x:x+offset,y:y+side*.356,h:.12+j*.23,sx:.095,sy:.065,sz:.014,color:zone==='R'?0xf3dfa6:0x95efff});
     add(x,y+.356,.19,.14,.24,.016,0x284756);
     if(c.level>1)add(x+.15,y-.12,h+.3,.30,.35,.36,baseColor);
    }
    if(c.type==='hospital'){add(x,y,h+.17,.42,.04,.13,0xeb7f7c);add(x,y,h+.18,.13,.04,.42,0xeb7f7c);}
    if(c.type==='life'){for(const dx of [-.22,.22])add(x+dx,y,h+.25,.22,.32,.5,0x77d6a8);}
    if(c.type==='radiator'){for(let j=0;j<4;j++)add(x-.3+j*.2,y,h+.24,.045,.3,.8,0x9cd9ee);}
    if(c.type==='water')add(x,y,h+.22,.4,.2,.4,0x78d8f7);
    if(c.type==='power')add(x,y,h+.3,.28,.42,.28,0xfbe5aa);
    // Modular facade ribs, foundation and entrance apply to every operational building.
    add(x,y,.09,.84,.13,.84,0x416476);
    for(const dx of [-.34,.34])add(x+dx,y,h/2+.1,.035,h,.73,0x607f90);
    add(x,y+.377,.21,.18,.27,.025,c.enabled===false?0x5c6470:0x91d2cf);
    add(x,y+.40,.37,.29,.035,.12,def.color);
    if(c.type==='station'||c.type==='dock'||c.type==='airport')add(x,y,h+.24,.85,.12,.35,0xe1e6df);
    }
   }
   if(overlay==='power'&&c.wire||overlay==='water'&&c.pipe){lines.push({tile:i,x,y,h:.13,sx:.95,sy:.025,sz:.04,color:overlay==='power'?0xffd580:0x94ddff});lines.push({tile:i,x,y,h:.13,sx:.04,sy:.025,sz:.95,color:overlay==='power'?0xffd580:0x94ddff});}
   if(c.fire)lights.push({tile:i,x,y,h:1.3,sx:.3,sy:.6,sz:.3,color:0xff763b});
  });
  this.floor.instanceColor.needsUpdate=true;
  for(const [list,material] of [[pieces,this.mat],[lights,new THREE.MeshBasicMaterial({color:0xffffff})],[lines,new THREE.MeshBasicMaterial({color:0xffffff,depthTest:false,transparent:true,opacity:.9})]]){
   if(!list.length){if(material!==this.mat)material.dispose();continue;}const mesh=new THREE.InstancedMesh(this.box,material,list.length);
   list.forEach((p,n)=>{this.matrix(mesh,n,p.x,p.h,p.y,p.sx,p.sy,p.sz);mesh.setColorAt(n,this.color.setHex(p.color));});mesh.userData.tiles=list.map(p=>p.tile??idx(Math.round(p.x),Math.round(p.y)));list.forEach((p,n)=>{const start=this.growth.get(p.tile);if(start!==undefined&&now-start<2400)this.growing.push({mesh,n,p,start});});mesh.instanceMatrix.needsUpdate=true;mesh.instanceColor.needsUpdate=true;mesh.computeBoundingSphere();this.buildings.add(mesh);
  }
 }
 addRails(){
  const rail=new THREE.InstancedMesh(this.box,new THREE.MeshStandardMaterial({color:0x9bd5dc,metalness:.5,roughness:.4}),SIZE*3);let n=0;
  for(let x=0;x<SIZE;x++)for(const y of [7.5,43.5]){this.matrix(rail,n++,x,.17,y,1.02,.045,.04);if(x%2===0)this.matrix(rail,n++,x,.11,y,.035,.22,.035);}
  rail.count=n;this.world.add(rail);
 }
 enterNearby(){
  if(this.mode!=='walk')return;
  let best=-1,d=1.8;for(const i of this.valid){const c=this.state.cells[i];if(!INTERIORS[c.type]||!c.level||c.fire)continue;const [x,y]=xy(i),distance=Math.hypot(deltaX(this.walker.u,x-27.5),this.walker.v-y+27.5);if(distance<d){best=i;d=distance;}}
  if(best>=0)this.enterInterior(best);else this.cb.notice?.('靠近電廠、水廠、醫院、車站、港口、會館或垂直塔，再按 E 進入。');
 }
 enterInterior(i){
  const c=this.state?.cells[i];if(!c||!c.level||c.fire||!INTERIORS[c.type])return false;
  const [x,y]=xy(i);if(this.mode==='walk'&&Math.hypot(deltaX(this.walker.u,x-27.5),this.walker.v-y+27.5)>1.8){this.cb.notice?.('步行時請先靠近入口；也可切回建造視角安排參訪。');return false;}
  const safe=nearestWalkable(this.state.cells,x-27.5,y-26.8);if(!safe)return false;
  this.room?.dispose();this.room=new InteriorRoom(c.type);this.interiorTile=i;Object.assign(this.walker,safe,{jump:0,velocity:0});this.room.update(c,this.analysis,i,this.state.month);this.setMode('interior');return true;
 }

 setMode(mode){
  if(mode===this.mode)return;
  const oldMode=this.mode;if(oldMode==='interior'&&mode!=='interior'){this.room.dispose();this.room=null;this.target.set(...surface(this.walker.u,this.walker.v));}
  if(mode==='fly'){const [u,v]=localPoint(this.target.x,this.target.y,this.target.z);Object.assign(this.flyer,{u:oldMode==='walk'?this.walker.u:u,v:oldMode==='walk'?this.walker.v:v,h:8});}
  if(oldMode==='fly')this.target.set(...surface(this.flyer.u,this.flyer.v));
  if(mode==='walk'){
   if(!this.state)return;
   const [u,v]=localPoint(this.target.x,this.target.y,this.target.z);let best=null,distance=Infinity;
   for(const i of this.valid){if(!isRoad(this.state.cells[i].type))continue;const [x,y]=xy(i),d=deltaX(u,x-27.5)**2+(y-27.5-v)**2;if(d<distance&&canWalk(this.state.cells,x-27.5,y-27.5)){distance=d;best={u:x-27.5,v:y-27.5};}}
   best=best||nearestWalkable(this.state.cells,u,v);if(!best){this.cb.notice?.('甲板上沒有可站立的空間，請先拆除一格建築。');return;}
   if(this.mode!=='overview'&&canWalk(this.state.cells,u,v))best={u,v};
   Object.assign(this.walker,best,{jump:0,velocity:0});this.visitedWalk=true;
  }else if(mode==='build'){
   if(['walk','interior'].includes(this.mode)){this.target.set(...surface(this.walker.u,this.walker.v));this.distance=16;}
   else if(this.mode==='overview'){this.target.set(...surface(-8,-10));this.distance=37;}
   this.pitch=.84;
  }
  this.mode=mode;this.keys={};this.pointers.clear();this.start=null;this.setPreview([]);this.camera.fov=['walk','fly','interior'].includes(mode)?74:48;this.camera.updateProjectionMatrix();
  document.body.dataset.view=mode;document.querySelectorAll('[data-view-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.viewMode===mode);b.setAttribute('aria-pressed',String(b.dataset.viewMode===mode));});
  const hint=document.getElementById('view-hint');if(hint)hint.textContent=mode==='interior'?`${INTERIORS[this.state.cells[this.interiorTile].type]} · WASD 移動 · M 管理 · E 返回街道`:mode==='fly'?'WASD 飛行 · 空白上升 / C 下降 · Shift 加速 · G 返回建造':mode==='walk'?'WASD 移動 · 拖曳看四周 · 空白跳躍 · E 進入 · F 返回建造':mode==='overview'?'全站觀察 · 拖曳旋轉 · 點「建造」返回開放街區':'曙光懸臂 · 拖曳建造 · F 走進街區';
  const exit=document.getElementById('interior-exit');if(exit)exit.hidden=mode!=='interior';const manage=document.getElementById('interior-manage');if(manage)manage.hidden=mode!=='interior';
  this.cb.mode?.(mode);this.cameraUpdate();
 }
 ensureWalkable(){
  if(canWalk(this.state.cells,this.walker.u,this.walker.v))return;
  const safe=nearestWalkable(this.state.cells,this.walker.u,this.walker.v);
  if(safe){Object.assign(this.walker,safe,{jump:0,velocity:0});this.cb.notice?.('附近建築已開發，已將你移到最近的安全位置。');}
  else{this.setMode('build');this.cb.notice?.('街區沒有可站立空間，已返回建造視角。');}
 }
 permitsBuild(indices,tool){
  if(['interior','fly','overview'].includes(this.mode))return false;
  if(this.mode!=='walk'||!indices.includes(tileAt(this.walker.u,this.walker.v)))return true;
  return ['road','avenue','rail','wire','pipe','eraseWire','erasePipe','bulldoze','park'].includes(tool);
 }
 walk(dt){
  const w=this.walker,k=this.keys;if(!this.state)return;
  w.yaw+=((k.ArrowRight?1:0)-(k.ArrowLeft?1:0))*dt*1.6;
  w.pitch=Math.max(-1.3,Math.min(1.3,w.pitch+((k.ArrowUp?1:0)-(k.ArrowDown?1:0))*dt));
  const forward=(k.KeyW?1:0)-(k.KeyS?1:0),side=(k.KeyD?1:0)-(k.KeyA?1:0),speed=(k.ShiftLeft||k.ShiftRight?1.35:.7)*dt/Math.max(1,Math.hypot(forward,side));
  moveWalker(this.state.cells,w,(Math.sin(w.yaw)*forward+Math.cos(w.yaw)*side)*speed,(-Math.cos(w.yaw)*forward+Math.sin(w.yaw)*side)*speed);
  w.velocity-=3.5*dt;w.jump=Math.max(0,w.jump+w.velocity*dt);if(w.jump===0)w.velocity=0;
  this.cameraUpdate();
 }
 fly(dt){
  const w=this.flyer,k=this.keys;w.yaw+=((k.ArrowRight?1:0)-(k.ArrowLeft?1:0))*dt*1.6;w.pitch=Math.max(-1.3,Math.min(1.3,w.pitch+((k.ArrowUp?1:0)-(k.ArrowDown?1:0))*dt));
  const forward=(k.KeyW?1:0)-(k.KeyS?1:0),side=(k.KeyD?1:0)-(k.KeyA?1:0),speed=(k.ShiftLeft||k.ShiftRight?25:9)*dt/Math.max(1,Math.hypot(forward,side));
  w.u=wrapX(w.u+28+(Math.sin(w.yaw)*forward+Math.cos(w.yaw)*side)*speed)-28;w.v=Math.max(-38,Math.min(38,w.v+(-Math.cos(w.yaw)*forward+Math.sin(w.yaw)*side)*speed));
  w.h=Math.max(1,Math.min(65,w.h+((k.Space?1:0)-(k.KeyC||k.KeyQ?1:0))*speed));this.cameraUpdate();
 }
 walkInterior(dt){const p=this.room.position,k=this.keys;p.yaw+=((k.ArrowRight?1:0)-(k.ArrowLeft?1:0))*dt*1.6;p.pitch=Math.max(-1.3,Math.min(1.3,p.pitch+((k.ArrowUp?1:0)-(k.ArrowDown?1:0))*dt));const f=(k.KeyW?1:0)-(k.KeyS?1:0),side=(k.KeyD?1:0)-(k.KeyA?1:0),speed=2.3*dt/Math.max(1,Math.hypot(f,side));this.room.move((Math.sin(p.yaw)*f+Math.cos(p.yaw)*side)*speed,(-Math.cos(p.yaw)*f+Math.sin(p.yaw)*side)*speed);this.cameraUpdate();}
 setupPeople(){
  this.pedBodies=new THREE.InstancedMesh(this.box,new THREE.MeshStandardMaterial({color:0x93c8ce,roughness:.85}),64);
  this.pedHeads=new THREE.InstancedMesh(this.box,new THREE.MeshStandardMaterial({color:0xd7b995,roughness:.85}),64);
  this.pedLegs=new THREE.InstancedMesh(this.box,new THREE.MeshStandardMaterial({color:0x344853}),128);
  for(const mesh of [this.pedBodies,this.pedHeads,this.pedLegs]){mesh.frustumCulled=false;mesh.count=0;this.scene.add(mesh);}
 }
 updatePeople(){
  const s=this.state,a=this.analysis,homes=this.valid.filter(i=>s.cells[i].pop>0&&a.employed[i]>0&&a.access[i].length),jobs=this.valid.filter(i=>a.filled[i]>0&&a.access[i].length),routes=[];
  for(let h=0;h<homes.length&&routes.length<24;h++){
   const source=homes[h];for(let j=0;j<Math.min(jobs.length,12);j++){
    const target=jobs[(h+j)%jobs.length],path=roadRoute(s.cells,a.access[source][0],a.access[target][0]);if(path.length<2)continue;
    routes.push(path);break;
   }
  }
  const count=routes.length?Math.min(64,Math.ceil(a.stats.employed/3)):0;
  this.people=Array.from({length:count},(_,i)=>({path:routes[i%routes.length],offset:i*.731}));
  this.pedBodies.count=count;this.pedHeads.count=count;this.pedLegs.count=count*2;
  const el=document.getElementById('street-count');if(el)el.textContent=`街道行人 ${count} · 代表性通勤人流`;
 }
 animatePeople(){
  this.people.forEach((person,i)=>{
   const path=person.path,length=path.length-1,progress=(this.streetClock*.3+person.offset)%(length*2),reverse=progress>length,t=reverse?length*2-progress:progress,j=Math.min(length-1,Math.floor(t)),f=t-j;
   const [x,y]=xy(path[j]),[rawU,v]=xy(path[j+1]),u=x+deltaX(x,rawU),lane=i%2?.25:-.25;
   const px=x+(u-x)*f+(v-y)*lane,py=y+(v-y)*f-(u-x)*lane,bob=Math.sin(this.streetClock*9+i)*.006;
   this.matrix(this.pedBodies,i,px,.155+bob,py,.065,.105,.05);this.matrix(this.pedHeads,i,px,.225+bob,py,.049,.049,.049);
   for(let k=0;k<2;k++)this.matrix(this.pedLegs,i*2+k,px+(k?-.018:.018),.085,py+Math.sin(this.streetClock*9+i+k*Math.PI)*.021,.021,.075,.024);
  });
  for(const mesh of [this.pedBodies,this.pedHeads,this.pedLegs])mesh.instanceMatrix.needsUpdate=true;
 }
 animate(){this.frame=requestAnimationFrame(()=>this.animate());const now=performance.now(),dt=Math.min(.06,(now-this.lastFrame)/1000);this.lastFrame=now;if(document.hidden)return;
  const blocked=!!document.querySelector('dialog[open]');if(blocked)this.keys={};
  if(this.mode==='walk'&&!blocked)this.walk(dt);if(this.mode==='fly'&&!blocked)this.fly(dt);if(this.mode==='interior'&&!blocked)this.walkInterior(dt);
  if(!blocked&&this.simulationSpeed>0)this.streetClock+=dt*Math.min(2,this.simulationSpeed);
  this.animatePeople();
  const touched=new Set();this.growing=this.growing.filter(g=>{const f=Math.min(1,Math.max(.02,(now-g.start)/2400));this.matrix(g.mesh,g.n,g.p.x,.08+(g.p.h-.08)*f,g.p.y,g.p.sx,g.p.sy*f,g.p.sz);touched.add(g.mesh);return f<1;});for(const m of touched)m.instanceMatrix.needsUpdate=true;
  for(const [i,start] of this.growth)if(now-start>=2400)this.growth.delete(i);
  const t=now*.00006;for(let i=0;i<this.ships.length;i++){const a=t+i*Math.PI*2/7,r=55;this.ships[i].position.set(Math.sin(a)*r,18+Math.sin(a*3+i)*6,Math.cos(a)*r);this.ships[i].rotation.y=a;}
  if(this.state&&this.mode!=='interior'&&now-(this.lodTime||0)>900&&this.lodPosition?.distanceTo(this.camera.position)>22)this.update(this.state,this.analysis,this.overlay);
  const location=document.getElementById('location-status');if(location&&now-(this.locationTime||0)>150){this.locationTime=now;const p=this.mode==='walk'?this.walker:this.mode==='fly'?this.flyer:null;location.textContent=this.mode==='interior'?`室內位置 ${this.room.position.x.toFixed(1)}, ${this.room.position.z.toFixed(1)}`:p?`${district(tileAt(p.u,Math.max(-19,Math.min(15,p.v))))} · ${this.mode==='fly'?'高度 '+p.h.toFixed(1):'步行'} · ${p.u.toFixed(1)}, ${p.v.toFixed(1)}`:'';}
  this.renderer.render(this.mode==='interior'?this.room.scene:this.scene,this.camera);
 }
}
