import test from 'node:test';
import assert from 'node:assert/strict';
import {surface,localPoint,tileAt,canWalk,nearestWalkable,moveWalker,roadRoute} from './habitat.mjs';
import {createCity,build,serialize,deserialize,analyze} from './engine.mjs';
import {DECK,CELL_COUNT,idx,terrain} from './catalog.mjs';

test('Every curved deck tile maps back to its own address, including elevated building faces',()=>{
 for(let x=DECK.minX;x<=DECK.maxX;x++)for(let y=DECK.minY;y<=DECK.maxY;y++)for(const h of [0,.28,3.8]){
  const p=surface(x-27.5,y-27.5,h),q=localPoint(...p);assert.ok(Math.abs(q[0]-(x-27.5))<1e-10);assert.equal(tileAt(...q),idx(x,y));
 }
 assert.ok(surface(19.5,0)[1]>2);assert.ok(surface(-19.5,0)[1]>2);
});
test('Deck boundary prevents walking into space even across a long movement step',()=>{
 const s=createCity({starter:false}),p={u:19,v:15};moveWalker(s.cells,p,0,30);assert.ok(p.v<15.9);assert.ok(canWalk(s.cells,p.u,p.v));
 assert.equal(terrain(-1),false);assert.equal(terrain(CELL_COUNT),false);
});
test('New buildings block walking; demolition immediately opens the footprint',()=>{
 const s=createCity({starter:false});s.cash=1e6;const p={u:-8,v:-12.5};assert.ok(build(s,[idx(21,15)],'hospital').ok);
 moveWalker(s.cells,p,5,0);assert.ok(p.u<-7);assert.ok(canWalk(s.cells,p.u,p.v));
 assert.ok(build(s,[idx(21,15)],'bulldoze').ok);moveWalker(s.cells,p,2,0);assert.ok(p.u>-6);
});
test('Automatic development has a nearby safe relocation and can recover from a full deck',()=>{
 const s=createCity({starter:false});const u=20-27.5,v=20-27.5;assert.ok(build(s,[idx(20,20)],'R').ok);s.cells[idx(20,20)].level=1;
 assert.equal(canWalk(s.cells,u,v),false);const p=nearestWalkable(s.cells,u,v);assert.ok(p&&canWalk(s.cells,p.u,p.v));
 for(let i=0;i<s.cells.length;i++)if(terrain(i))Object.assign(s.cells[i],{type:'R',level:1});assert.equal(nearestWalkable(s.cells,u,v),null);
});
test('Representative pedestrians follow connected streets and lose routes after demolition',()=>{
 const s=createCity({starter:false});build(s,[10,11,12,13,14].map(x=>idx(x,15)),'road');
 assert.equal(roadRoute(s.cells,idx(10,15),idx(14,15)).length,5);build(s,[idx(12,15)],'bulldoze');assert.deepEqual(roadRoute(s.cells,idx(10,15),idx(14,15)),[]);
});
test('Habitat saves round trip and explicitly reject legacy flat-map saves',()=>{
 const s=createCity(),loaded=deserialize(serialize(s));assert.equal(analyze(loaded).stats.population,120);const raw=JSON.parse(serialize(s));raw.version=1;assert.throws(()=>deserialize(JSON.stringify(raw)));
});
