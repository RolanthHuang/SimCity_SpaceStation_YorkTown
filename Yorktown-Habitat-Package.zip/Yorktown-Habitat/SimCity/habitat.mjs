import {DECK,SIZE,HEIGHT,idx,xy,terrain,isTransport,neighbors,wrapX,deltaX} from './catalog.mjs';

// Intrinsic deck coordinates preserve the simulation's unit-distance road network.
// World-space Y points toward the station centre; local gravity follows the deck normal.
export function surface(u,v,h=0){const a=u/DECK.radius,r=DECK.radius-h;return [r*Math.sin(a),DECK.radius-r*Math.cos(a),v];}
export const wrapU=u=>wrapX(u+28)-28;
export function localPoint(x,y,z){return [wrapU(Math.atan2(x,DECK.radius-y)*DECK.radius),z];}
export function tileAt(u,v){const x=wrapX(Math.floor(u+28)),y=Math.floor(v+28);return y>=0&&y<HEIGHT?idx(x,y):-1;}
export function solid(c){return !!(c?.type&&c.level>0&&!isTransport(c.type)&&!['park','rubble'].includes(c.type));}
export function canWalk(cells,u,v,radius=.12){
 for(const du of [-radius,radius])for(const dv of [-radius,radius])if(!terrain(tileAt(u+du,v+dv)))return false;
 const cx=Math.floor(u+28),cy=Math.floor(v+28);
 for(let y=cy-1;y<=cy+1;y++)for(let x=cx-1;x<=cx+1;x++){
  if(y<0||y>=HEIGHT)continue;
  if(solid(cells[idx(wrapX(x),y)])&&Math.abs(deltaX(u,x-27.5))<.39+radius&&Math.abs(v-(y-27.5))<.39+radius)return false;
 }
 return true;
}
export function nearestWalkable(cells,u,v){
 let result=null,best=Infinity;
 for(let i=0;i<cells.length;i++){if(!terrain(i))continue;const [x,y]=xy(i),a=x-27.5,b=y-27.5;if(!canWalk(cells,a,b))continue;const d=deltaX(u,a)**2+(b-v)**2;if(d<best){best=d;result={u:a,v:b};}}
 return result;
}
export function moveWalker(cells,position,du,dv){
 // Small substeps prevent tunnelling across buildings, even after a slow frame.
 const steps=Math.max(1,Math.ceil(Math.hypot(du,dv)/.06));
 for(let j=0;j<steps;j++){if(canWalk(cells,position.u+du/steps,position.v))position.u+=du/steps;if(canWalk(cells,position.u,position.v+dv/steps))position.v+=dv/steps;}
 position.u=wrapU(position.u);return position;
}
export function roadRoute(cells,start,goal){
 if(start===goal)return [start];
 if(!isTransport(cells[start]?.type)||!isTransport(cells[goal]?.type))return [];
 const queue=[start],previous=new Map([[start,-1]]);
 for(let k=0;k<queue.length;k++){
  const i=queue[k],[x,y]=xy(i);
  for(const n of neighbors(i)){
   // Street pedestrians do not walk down rail tracks.
   if(n<0||previous.has(n)||!['road','avenue'].includes(cells[n]?.type))continue;
   previous.set(n,i);if(n===goal){const path=[n];while(previous.get(path[0])!==-1)path.unshift(previous.get(path[0]));return path;}queue.push(n);
  }
 }
 return [];
}
