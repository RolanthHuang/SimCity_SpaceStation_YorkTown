import * as THREE from '../YorktownPreview/three.module.js';
import {TYPES,INTERIORS,isEnabled} from './catalog.mjs';

// Instanced exterior buildings stay lightweight. Only the visited interior exists.
export class InteriorRoom{
 constructor(type){
  this.type=type;this.scene=new THREE.Scene();this.scene.background=new THREE.Color(0x071321);this.obstacles=[];this.resources=[];
  const ambient=new THREE.HemisphereLight(0xd0f6ff,0x3a5362,3.5);this.scene.add(ambient);
  const lamp=new THREE.PointLight(0xbef1ff,40,20);lamp.position.set(0,3,0);this.scene.add(lamp);
  this.boxGeometry=new THREE.BoxGeometry(1,1,1);this.resources.push(this.boxGeometry);
  const material=(color,glow=false)=>{const m=glow?new THREE.MeshBasicMaterial({color}):new THREE.MeshStandardMaterial({color,roughness:.6,metalness:.22});this.resources.push(m);return m;};
  const wall=material(0x273f50),floor=material(0x344c5c),light=material(0x98e8df,true),dark=material(0x122635),trim=material(TYPES[type].color),glass=material(0x4eb7cc,true);
  const box=(x,y,z,w,h,d,m,solid=false)=>{const mesh=new THREE.Mesh(this.boxGeometry,m);mesh.position.set(x,y,z);mesh.scale.set(w,h,d);this.scene.add(mesh);if(solid)this.obstacles.push({x,z,w,d});return mesh;};
  box(0,-.12,0,8,.24,10,floor);box(-4,1.8,0,.2,3.6,10,wall);box(4,1.8,0,.2,3.6,10,wall);box(0,1.8,-5,8,3.6,.2,wall);
  box(-2.5,1.8,5,3,3.6,.2,wall);box(2.5,1.8,5,3,3.6,.2,wall);box(0,3.3,5,2,.6,.2,wall);
  for(const x of [-3.8,3.8])box(x,3.3,0,.06,.06,9.8,light);
  for(let z=-4;z<5;z++)box(0,.015,z,7.8,.015,.018,dark);
  box(0,.02,4.55,1.6,.03,.32,light);box(0,3.3,0,.6,.06,8,light);
  const technical=['power','water','life','radiator','dock'].includes(type);
  if(technical){
   for(const side of [-1,1])for(let z=-2.4;z<=1.3;z+=1.8){box(side*2.8,.65,z,1.3,1.3,1.2,dark,true);box(side*2.8,1.34,z,1.2,.06,1.1,glass);box(side*3.3,1.8,z,.35,.6,.8,trim);}
   if(type==='life'){for(const x of [-2.6,2.6]){box(x,2.3,-3.5,1,1.1,1,trim);box(x,1.1,-3.5,1.1,1.1,1.1,dark,true);}}
  }else if(type==='hospital'){
   for(const x of [-2.7,2.7])for(const z of [-2,1]){box(x,.58,z,1.1,.45,2,material(0xd6e6e9),true);box(x,.85,z-.65,.8,.15,.45,trim);box(x,1.5,z-1,.9,.7,.12,dark);}
  }else{
   for(const x of [-2.7,2.7])for(const z of [-1.5,1.5]){box(x,.43,z,1.2,.75,1.8,trim,true);box(x+(x<0?-.5:.5),1,z,.2,.55,1.8,dark);}
   box(0,.55,-3.4,3,1.1,.65,dark,true);box(0,1.16,-3.4,3.1,.1,.8,trim);
  }
  this.canvas=document.createElement('canvas');this.canvas.width=1024;this.canvas.height=512;this.texture=new THREE.CanvasTexture(this.canvas);this.texture.colorSpace=THREE.SRGBColorSpace;this.resources.push(this.texture);
  const screenMat=new THREE.MeshBasicMaterial({map:this.texture});this.resources.push(screenMat);const screenGeo=new THREE.PlaneGeometry(4.8,2.4);this.resources.push(screenGeo);const screen=new THREE.Mesh(screenGeo,screenMat);screen.position.set(0,2,-4.85);this.scene.add(screen);
  this.position={x:0,z:3.7,yaw:0,pitch:0};
 }
 update(c,a,i,month){
  const ctx=this.canvas.getContext('2d');ctx.fillStyle='#071e2c';ctx.fillRect(0,0,1024,512);ctx.fillStyle='#9af0d4';ctx.font='32px system-ui';ctx.fillText('YORKTOWN / '+INTERIORS[this.type],40,62);ctx.fillStyle='#e2f0f7';ctx.font='25px system-ui';
  const lines=[`殖民曆 ${2263+Math.floor(month/12)} / ${month%12+1}   ·   ${isEnabled(c)?'營運中':'已暫停'}`,`供電 ${Math.round(a.power.coverage[i]*100)}%     供水 ${Math.round(a.water.coverage[i]*100)}%`,`氧氣 ${Math.round(a.space.oxygen[i]*100)}%     散熱 ${Math.round(a.space.cooling[i]*100)}%`,`居民 ${c.pop}    就業 ${a.filled[i]} / ${a.jobs[i]}    設備 ${c.upgrade||0} / 2`,'M 開啟營運管理   ·   E 返回街道'];
  lines.forEach((line,n)=>ctx.fillText(line,40,135+n*66));this.texture.needsUpdate=true;
 }
 move(dx,dz){
  const p=this.position,can=(x,z)=>Math.abs(x)<3.65&&z>-4.55&&z<4.65&&!this.obstacles.some(o=>Math.abs(x-o.x)<o.w/2+.22&&Math.abs(z-o.z)<o.d/2+.22);
  const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.1));for(let k=0;k<steps;k++){if(can(p.x+dx/steps,p.z))p.x+=dx/steps;if(can(p.x,p.z+dz/steps))p.z+=dz/steps;}
 }
 dispose(){this.resources.forEach(r=>r.dispose());}
}
