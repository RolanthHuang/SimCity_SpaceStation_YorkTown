import * as THREE from './three.module.js';
// Bundled into the final HTML; the game has no runtime network dependency.
const D=window.YORKTOWN;
const $=id=>document.getElementById(id);
const scene=new THREE.Scene();scene.background=new THREE.Color('#050d1b');
const camera=new THREE.PerspectiveCamera(58,1,.15,18000);camera.up.set(0,0,1);
let renderer;
try {renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});}
catch(e){$('loading').textContent='WebGL is unavailable. Open this file in Chrome or Safari with hardware acceleration enabled.';throw e;}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.95;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
$('viewport').appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-label','Yorktown 3D exploration viewport');
const geometryRoot=new THREE.Group();scene.add(geometryRoot);
for(const spec of D.meshes){
 const positions=[];
 for(const face of spec.faces)for(let i=1;i<face.length-1;i++)for(const idx of [face[0],face[i],face[i+1]])positions.push(...spec.vertices[idx]);
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.computeVertexNormals();g.computeBoundingSphere();
 const s=D.materials[spec.material],color=new THREE.Color(...s.color);
 const mat=new THREE.MeshStandardMaterial({color,roughness:s.rough,metalness:s.metal,emissive:s.emit?color:0,emissiveIntensity:(s.emit||0)*.42});
 const m=new THREE.Mesh(g,mat);m.name=spec.name;m.userData.collision=spec.collision;m.castShadow=/District|Wing|Civic|Conservatory|Parked|Observation/.test(spec.name);m.receiveShadow=true;geometryRoot.add(m);
}
scene.add(new THREE.HemisphereLight(0xbde5f6,0x243544,1.6));
for(const [c,int,p] of [[0xc5e6ff,2.4,[1200,-2000,2400]],[0xffbe81,1.5,[-1200,1000,300]],[0x377fff,2.4,[0,1000,-2000]]]){
 const l=new THREE.DirectionalLight(c,int);l.position.set(...p);scene.add(l);
}
// A moving shadow window gives the nearby architecture depth without shadowing kilometres of scenery.
const walkSun=new THREE.DirectionalLight(0xffe5bc,1.6);walkSun.castShadow=true;
walkSun.shadow.mapSize.set(2048,2048);Object.assign(walkSun.shadow.camera,{left:-100,right:100,top:100,bottom:-100,near:10,far:500});
walkSun.shadow.bias=-.0002;walkSun.shadow.normalBias=.12;scene.add(walkSun,walkSun.target);
for(const label of D.labels){
 const cv=document.createElement('canvas');cv.width=1024;cv.height=128;const ctx=cv.getContext('2d');
 ctx.fillStyle='#071b29';ctx.fillRect(0,0,1024,128);ctx.strokeStyle='#8cd4e4';ctx.lineWidth=3;ctx.strokeRect(4,4,1016,120);
 ctx.fillStyle='#d4f5ed';ctx.font='500 48px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label.text,512,64);
 const tex=new THREE.CanvasTexture(cv);tex.colorSpace=THREE.SRGBColorSpace;
 const sign=new THREE.Mesh(new THREE.PlaneGeometry(label.width,label.width/8),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}));sign.position.set(...label.position);sign.rotation.x=Math.PI/2;scene.add(sign);
}
// A translucent shell is visual atmosphere, separate from the structural grid.
const shell=new THREE.Mesh(new THREE.SphereGeometry(1167,48,32),new THREE.MeshBasicMaterial({color:0x329ddb,transparent:true,opacity:.032,side:THREE.DoubleSide,depthWrite:false}));scene.add(shell);
let seed=2263;function rand(){seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;}
const stars=[];for(let i=0;i<2000;i++){const z=rand()*2-1,a=rand()*Math.PI*2,r=7000,s=Math.sqrt(1-z*z);stars.push(r*s*Math.cos(a),r*s*Math.sin(a),r*z);}
const sg=new THREE.BufferGeometry();sg.setAttribute('position',new THREE.Float32BufferAttribute(stars,3));scene.add(new THREE.Points(sg,new THREE.PointsMaterial({color:0xc4dafa,size:5,sizeAttenuation:true})));
const markers=D.checkpoints.map((cp,i)=>{
 const group=new THREE.Group();group.position.set(...cp.position);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(1.3,.055,6,48),new THREE.MeshBasicMaterial({color:0xffc277}));ring.rotation.x=Math.PI/2;group.add(ring);
 const pillar=new THREE.Mesh(new THREE.CylinderGeometry(.08,.08,4,6),new THREE.MeshBasicMaterial({color:0xffc277}));pillar.rotation.x=Math.PI/2;group.add(pillar);
 scene.add(group);return group;
});
const sectorMarkers=D.flight_sectors.map(cp=>{
 const group=new THREE.Group();group.position.set(...cp.position);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(38,1.1,6,64),new THREE.MeshBasicMaterial({color:0x80dcee,transparent:true,opacity:.8}));group.add(ring);scene.add(group);return group;
});
// Animated local shuttle traffic. Every route stays within the enclosing globe.
const shuttles=[];for(let i=0;i<12;i++){
 const group=new THREE.Group();const body=new THREE.Mesh(new THREE.BoxGeometry(7,16,4),new THREE.MeshStandardMaterial({color:0xc4d8de,metalness:.6,roughness:.3}));group.add(body);
 const light=new THREE.Mesh(new THREE.BoxGeometry(6,1,1.1),new THREE.MeshBasicMaterial({color:0x58d7ff}));light.position.set(0,-8,0);group.add(light);scene.add(group);shuttles.push(group);
}
const state={mode:'orbit',orbitAngle:-.96,orbitHeight:1600,orbitRadius:2800,yaw:0,pitch:.05,keys:{},paused:false,found:new Set(),sectors:new Set(),yawDrag:0,quality:'high',t:0};
let dragging=false,last={x:0,y:0},jumpVelocity=0;
const spawn=new THREE.Vector3(...D.district.spawn),position=spawn.clone();
const colliders=D.colliders.filter(c=>!c.name.endsWith('Floor'));
const checkpointUI=()=>{
 $('progress').textContent=`${state.found.size} / ${D.checkpoints.length} landmarks · ${state.sectors.size} / ${D.flight_sectors.length} flight sectors`;
 $('landmarks').innerHTML=D.zones.map((z,i)=>`<button data-zone='${i}' title='Start walking in ${z.name}'>${['01','02','03'][i]} ${['Civic','Aurora','Horizon'][i]} ↗</button>`).join('');
};checkpointUI();
$('landmarks').onclick=e=>{
 const button=e.target.closest('[data-zone]');if(!button)return;
 setMode('walk');const views=[[12,-54,Math.PI/2],[-565,-88,.78],[563,-84,2.35]],v=views[Number(button.dataset.zone)];position.set(v[0],v[1],spawn.z);state.yaw=v[2];state.pitch=.14;
 $('toast').textContent='District arrival · walk the bridges to explore the connected map.';
};
const mapCanvas=$('map'),mapCtx=mapCanvas.getContext('2d');
function drawMap(){
 const ctx=mapCtx,W=mapCanvas.width,H=mapCanvas.height;ctx.clearRect(0,0,W,H);
 const px=x=>(x+610)/1220*W,py=y=>H/2-y/300*H;
 ctx.fillStyle='#234152';ctx.strokeStyle='#477183';ctx.lineWidth=1;
 for(const [a,b,c,d] of D.walk_regions){ctx.fillRect(px(a),py(d),px(b)-px(a),py(c)-py(d));ctx.strokeRect(px(a),py(d),px(b)-px(a),py(c)-py(d));}
 for(let i=0;i<D.checkpoints.length;i++){
  const [x,y]=D.checkpoints[i].position;ctx.fillStyle=state.found.has(i)?'#80eabd':'#ffc979';ctx.beginPath();ctx.arc(px(x),py(y),5,0,Math.PI*2);ctx.fill();
  ctx.font='16px system-ui';ctx.textAlign='center';ctx.fillText(i+1,px(x),py(y)-9);
 }
 if(state.mode==='walk'){
  const x=px(position.x),y=py(position.y);ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(x,y,6,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(state.yaw)*17,y-Math.sin(state.yaw)*17);ctx.stroke();
 }
}
function supportAt(x,y){return D.walk_regions.some(([a,b,c,d])=>x>=a+.48&&x<=b-.48&&y>=c+.48&&y<=d-.48);}
function canStandAt(x,y,z){return supportAt(x,y)&&!collisionAt(x,y,z);}
function setMode(mode){
 state.mode=mode;state.keys={};state.paused=false;jumpVelocity=0;
 if(mode==='walk'){position.copy(spawn);state.yaw=Math.PI/2;state.pitch=.08;}
 if(mode==='fly'){position.set(420,-1250,380);state.yaw=1.9;state.pitch=-.28;}
 if(mode==='orbit'){state.orbitRadius=2800;state.orbitHeight=1400;state.orbitAngle=-.96;}
 for(const el of document.querySelectorAll('[data-mode]')){el.classList.toggle('active',el.dataset.mode===mode);el.setAttribute('aria-pressed',String(el.dataset.mode===mode));}
 $('mode').textContent=mode==='orbit'?'STATION OVERVIEW':mode==='walk'?'CIVIC PROMENADE':'FREE FLIGHT';renderer.shadowMap.enabled=mode==='walk'&&state.quality==='high';walkSun.visible=mode==='walk';$('map-panel').hidden=mode==='fly';
 $('help').textContent=mode==='orbit'?'Drag to orbit · Scroll to zoom':mode==='walk'?'W A S D to walk · Drag to look · Shift to run · Space to jump':'W A S D to fly · Drag to look · E / Q up / down · Shift to boost';
 $('crosshair').hidden=mode==='orbit';$('touch').hidden=mode==='orbit';
 $('toast').textContent=mode==='walk'?'Follow the nine landmarks across three connected districts.':mode==='fly'?'Flight mode is free exploration; press Walk to return safely.':'Yorktown awaits.';
 resize();
}
for(const el of document.querySelectorAll('[data-mode]'))el.addEventListener('click',()=>setMode(el.dataset.mode));
$('reset').onclick=()=>{state.found.clear();state.sectors.clear();markers.forEach(g=>g.children.forEach(m=>m.material.color.set(0xffc277)));sectorMarkers.forEach(g=>g.children[0].material.color.set(0x80dcee));checkpointUI();setMode(state.mode);};
$('quality').onchange=e=>{state.quality=e.target.value;renderer.setPixelRatio(state.quality==='high'?Math.min(devicePixelRatio,1.6):1);shell.visible=state.quality==='high';renderer.shadowMap.enabled=state.mode==='walk'&&state.quality==='high';resize();};
function keydown(e){if(/INPUT|SELECT/.test(e.target.tagName))return;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();state.keys[e.code]=true;if(e.code==='Digit1')setMode('orbit');if(e.code==='Digit2')setMode('walk');if(e.code==='Digit3')setMode('fly');if(e.code==='KeyR')setMode(state.mode);if(e.code==='Escape'){state.paused=!state.paused;$('toast').textContent=state.paused?'Paused · press Esc to resume':'';state.keys={};}}
addEventListener('keydown',keydown);addEventListener('keyup',e=>state.keys[e.code]=false);addEventListener('blur',()=>{state.keys={};dragging=false;});
renderer.domElement.addEventListener('pointerdown',e=>{dragging=true;last={x:e.clientX,y:e.clientY};renderer.domElement.setPointerCapture(e.pointerId);});
renderer.domElement.addEventListener('pointerup',()=>dragging=false);
renderer.domElement.addEventListener('pointercancel',()=>dragging=false);
renderer.domElement.addEventListener('pointermove',e=>{if(!dragging)return;let dx=e.clientX-last.x,dy=e.clientY-last.y;last={x:e.clientX,y:e.clientY};if(state.mode==='orbit'){state.orbitAngle-=dx*.004;state.orbitHeight=Math.max(-2800,Math.min(2800,state.orbitHeight+dy*5));}else{state.yaw-=dx*.003;state.pitch=Math.max(-1.45,Math.min(1.45,state.pitch-dy*.003));}});
renderer.domElement.addEventListener('wheel',e=>{if(state.mode==='orbit'){e.preventDefault();state.orbitRadius=Math.max(350,Math.min(6500,state.orbitRadius+e.deltaY*2));}},{passive:false});
for(const b of document.querySelectorAll('[data-key]')){b.onpointerdown=e=>{e.preventDefault();state.keys[b.dataset.key]=true;b.setPointerCapture(e.pointerId);};b.onpointerup=b.onpointercancel=()=>state.keys[b.dataset.key]=false;}
function collisionAt(x,y,z){
 const radius=.48;
 for(const c of colliders){const [cx,cy,cz]=c.center,[sx,sy,sz]=c.size;if(z-1.7>cz+sz/2||z+.1<cz-sz/2)continue;if(x>cx-sx/2-radius&&x<cx+sx/2+radius&&y>cy-sy/2-radius&&y<cy+sy/2+radius)return true;}
 return false;
}
function step(dt){
 if(state.paused)return;
 const k=state.keys;
 if(state.mode==='orbit'){
  if(!dragging&&!matchMedia('(prefers-reduced-motion: reduce)').matches)state.orbitAngle+=dt*.035;
  camera.position.set(state.orbitRadius*Math.cos(state.orbitAngle),state.orbitRadius*Math.sin(state.orbitAngle),state.orbitHeight);camera.lookAt(0,0,0);
 }else{
  state.yaw+=((k.ArrowLeft?1:0)-(k.ArrowRight?1:0))*dt*1.2;state.pitch=Math.max(-1.45,Math.min(1.45,state.pitch+((k.ArrowUp?1:0)-(k.ArrowDown?1:0))*dt));
  const forward=(k.KeyW?1:0)-(k.KeyS?1:0),side=(k.KeyD?1:0)-(k.KeyA?1:0),n=Math.max(1,Math.hypot(forward,side));
  const speed=state.mode==='walk'?(k.ShiftLeft||k.ShiftRight?13:6):(k.ShiftLeft||k.ShiftRight?330:95);
  const dx=(Math.cos(state.yaw)*forward+Math.sin(state.yaw)*side)/n*speed*dt;
  const dy=(Math.sin(state.yaw)*forward-Math.cos(state.yaw)*side)/n*speed*dt;
  if(state.mode==='walk'){
   if(k.Space&&position.z<=spawn.z+.01)jumpVelocity=5;
   jumpVelocity-=9.81*dt;position.z=Math.max(spawn.z,position.z+jumpVelocity*dt);if(position.z===spawn.z)jumpVelocity=0;
   const nx=position.x+dx,ny=position.y+dy;
   if(canStandAt(nx,position.y,position.z))position.x=nx;if(canStandAt(position.x,ny,position.z))position.y=ny;
   for(let i=0;i<D.checkpoints.length;i++)if(!state.found.has(i)&&position.distanceTo(new THREE.Vector3(...D.checkpoints[i].position))<7){state.found.add(i);markers[i].children.forEach(m=>m.material.color.set(0x75ffc4));checkpointUI();$('toast').textContent=state.found.size===D.checkpoints.length?'All nine landmarks found. Switch to Fly for the station survey.':`${D.checkpoints[i].name} · ${D.checkpoints[i].description}`;}
  }else{position.x+=dx;position.y+=dy;position.z+=((k.KeyE?1:0)-(k.KeyQ?1:0))*speed*dt;position.z+=Math.sin(state.pitch)*forward*speed*dt; if(position.length()>6500)position.setLength(6500);
   for(let i=0;i<D.flight_sectors.length;i++)if(!state.sectors.has(i)&&position.distanceTo(new THREE.Vector3(...D.flight_sectors[i].position))<70){state.sectors.add(i);sectorMarkers[i].children[0].material.color.set(0x85ffc4);checkpointUI();$('toast').textContent=state.sectors.size===6?'Station survey complete. All six sectors discovered.':`${D.flight_sectors[i].name} discovered`;}
  }
  camera.position.copy(position);camera.lookAt(position.x+Math.cos(state.yaw)*Math.cos(state.pitch),position.y+Math.sin(state.yaw)*Math.cos(state.pitch),position.z+Math.sin(state.pitch));
 }
}
function resize(){const r=$('viewport').getBoundingClientRect();renderer.setSize(r.width,r.height);camera.aspect=r.width/r.height;camera.fov=state.mode==='orbit'?THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(THREE.MathUtils.degToRad(58)/2)/Math.min(1,camera.aspect))):58;camera.updateProjectionMatrix();}addEventListener('resize',resize);resize();
let previous=performance.now(),frameCount=0,fpsTime=previous;
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-previous)/1000,.04);previous=now;state.t+=state.paused?0:dt;step(dt);
 shuttles.forEach((s,i)=>{const a=state.t*.025+i*TAU/12,r=380+i%3*130;s.position.set(r*Math.cos(a),r*Math.sin(a),140*Math.sin(a*2+i));s.rotation.z=a;});
 markers.forEach(m=>{m.rotation.z=state.t*.3;});renderer.render(scene,camera);frameCount++;if(now-fpsTime>800){$('fps').textContent=`${Math.round(frameCount*1000/(now-fpsTime))} FPS`;frameCount=0;fpsTime=now;}
 if(state.mode!=='orbit'){
  let nearest=null,distance=Infinity;
  const items=state.mode==='walk'?D.checkpoints:D.flight_sectors,visited=state.mode==='walk'?state.found:state.sectors;
  items.forEach((s,i)=>{if(!visited.has(i)){const d=position.distanceTo(new THREE.Vector3(...s.position));if(state.mode==='walk'?!nearest:d<distance){nearest=s;distance=d;}}});
  let arrow='';if(nearest){const a=Math.atan2(nearest.position[1]-position.y,nearest.position[0]-position.x)-state.yaw,angle=Math.atan2(Math.sin(a),Math.cos(a));arrow=Math.abs(angle)<.45?'↑':Math.abs(angle)>2.65?'↓':angle>0?'←':'→';}
  $('target').textContent=nearest?`${arrow} ${nearest.name} · ${Math.round(distance)} m`:state.mode==='walk'?'✓ Walking survey complete — try Fly':'✓ Station survey complete';
  $('target').style.left='50%';$('target').style.top='24%';$('target').hidden=false;
 }else $('target').hidden=true;
 if(state.mode==='walk'){
  const zone=D.zones.find(z=>{const [a,b,c,d]=z.bounds;return position.x>=a&&position.x<=b&&position.y>=c&&position.y<=d;});$('mode').textContent=zone?zone.name:'TRANSFER BRIDGE';
  walkSun.position.set(position.x+110,position.y-150,position.z+200);walkSun.target.position.set(position.x,position.y,position.z-1.75);walkSun.target.updateMatrixWorld();
 }
 if(frameCount%6===0)drawMap();
}
const TAU=Math.PI*2;setMode('orbit');$('loading').hidden=true;requestAnimationFrame(animate);
// App-owned deterministic regression runner. Results are exposed as ordinary page content.
if(new URLSearchParams(location.search).has('test')){
 const checks=[];const check=(name,ok,detail)=>checks.push({name,passed:!!ok,...(detail?{detail}:{})});
 setMode('walk');const start=position.clone();state.keys.KeyW=true;for(let i=0;i<60;i++)step(1/60);state.keys={};check('Walking speed is six metres per second',Math.abs(position.distanceTo(start)-6)<.01);
 check('Spawn is supported and unobstructed',canStandAt(spawn.x,spawn.y,spawn.z));
 check('Three district buildings block movement',collisionAt(-118,51,spawn.z)&&collisionAt(-363,80,spawn.z)&&collisionAt(360,78,spawn.z));
 check('Space beside the bridges cannot be walked on',!supportAt(215,45)&&!supportAt(-215,-45));
 check('Both bridge joins have continuous floor support',[-280,-150,150,280].every(x=>canStandAt(x,0,spawn.z)));
 position.set(210,0,spawn.z);state.yaw=Math.PI/2;state.keys.KeyW=true;for(let i=0;i<300;i++)step(1/60);state.keys={};check('Bridge railing stops outward walking',position.y<11.2&&position.y>9);
 position.copy(spawn);state.keys.Space=true;step(1/60);state.keys={};check('Jump leaves the ground',position.z>spawn.z);for(let i=0;i<180;i++)step(1/60);check('Jump returns to the floor',Math.abs(position.z-spawn.z)<.001);
 // Traverse the entire planned route through the real movement controller; no landmark teleports.
 setMode('walk');state.found.clear();let routeOk=true,walked=0;
 for(const segment of D.walk_route){
  for(const [x,y] of segment.points){
   let limit=0;
   while(Math.hypot(position.x-x,position.y-y)>.12&&limit++<14000){
    state.yaw=Math.atan2(y-position.y,x-position.x);state.keys={KeyW:true};const before=position.clone();step(1/60);walked+=position.distanceTo(before);
    if(position.distanceTo(before)<.0001){routeOk=false;break;}
   }
   if(limit>=14000)routeOk=false;if(!routeOk)break;
  }
  if(!routeOk)break;
 }
 state.keys={};check('Full nine-landmark route is traversable without teleporting',routeOk&&state.found.size===9,`${Math.round(walked)} metres traversed; ${state.found.size}/9 found`);
 check('All landmark positions have clear standing space',D.checkpoints.every(c=>canStandAt(...c.position)));
 check('District quick-start positions are clear',[[-565,-88],[563,-84]].every(([x,y])=>canStandAt(x,y,spawn.z)));
 setMode('fly');const from=position.clone();state.keys.KeyW=true;for(let i=0;i<60;i++)step(1/60);state.keys={};check('Flight traverses the station',position.distanceTo(from)>90);
 for(const sector of D.flight_sectors){position.set(...sector.position);step(1/60);}check('Six flight sector triggers register',state.sectors.size===6);
 $('reset').click();check('Reset clears both surveys',state.found.size===0&&state.sectors.size===0);
 setMode('walk');state.paused=true;state.keys.KeyW=true;const paused=position.clone();step(.1);check('Pause stops movement',position.equals(paused));setMode('orbit');
 check('All mesh positions are finite',D.meshes.every(m=>m.vertices.every(v=>v.every(Number.isFinite))));
 const report=document.createElement('pre');report.id='test-results';report.style='position:fixed;top:150px;left:25px;background:#061725f5;padding:18px;color:#c4fff0;z-index:10;font:12px monospace;max-width:90%;max-height:60vh;overflow:auto;white-space:pre-wrap';report.textContent=JSON.stringify({passed:checks.every(c=>c.passed),checks},null,2);document.body.append(report);
}
